
#include "xtsdkLibHandler.h"
#include <sstream>
namespace XinTan
{

    LibHandler::LibHandler(std::string &logtag) : logtagname(logtag)
    {
        // logtagname = logtag;
#ifdef _WIN32
        lib_path = "xtsdk_shared.dll";
        // lib_path = std::string(PROJECT_DIR) + "/xtsdk/lib/win32/xtsdk_shared.dll";
        std::cout << "start loading win32 lib " << lib_path << std::endl;
        handle = LoadLibrary(lib_path.c_str());
        if (!handle)
        {
            std::cerr << "Cannot open library: " << GetLastError() << std::endl;
            bLibLoadSuccess = false;
            return;
            // exit(1);
        }
        std::cout << "loading win32 success " << lib_path << std::endl;
        bLibLoadSuccess = true;
        CreateBaseFilterFunc createBaseFilter = (CreateBaseFilterFunc)GetProcAddress(handle, "createBaseFilter");

#else
        // #ifdef ARCH_X86_64
        //         lib_path = std::string(PROJECT_DIR) + "/xtsdk/lib/linux/x86_64/libxtsdk_shared.so";
        // #else
        //         lib_path = std::string(PROJECT_DIR) + "/xtsdk/lib/linux/aarch64/libxtsdk_shared.so";
        // #endif
        lib_path = std::string(LIB_DIR) + "/libxtsdk_shared.so";
        std::cout << "start loading linux lib " << lib_path << std::endl;
        handle = dlopen(lib_path.c_str(), RTLD_LAZY);
        if (!handle)
        {
            std::cerr << "Failed to load the library: " << dlerror() << std::endl;
            bLibLoadSuccess = false;
            return;
            // exit(1);
        }
        std::cout << "loading linux success " << lib_path << std::endl;
        bLibLoadSuccess = true;
        CreateBaseFilterFunc createBaseFilter = (CreateBaseFilterFunc)dlsym(handle, "createBaseFilter");

#endif
        if (!createBaseFilter)
        {
            std::cerr << "Cannot load symbol createBaseFilter" << std::endl;
#if defined(_WIN32) || defined(_WIN64)
            FreeLibrary(handle);
#else
            dlclose(handle);
#endif
            // exit(1);
            bLibLoadSuccess = false;
            return;
        }
        bLibLoadSuccess = true;
        filter = createBaseFilter(xtdlllogger);
    }

    LibHandler::~LibHandler()
    {
#ifdef _WIN32
        if (handle)
        {
            FreeLibrary(handle);
        }
#else
        if (handle)
        {
            dlclose(handle);
        }
#endif
    }
    bool LibHandler::setDustFilterLib(uint16_t threshold,
                                      uint16_t framecount,
                                      uint16_t validpercent,
                                      uint16_t timedf,
                                      std::mutex &filterLock,
                                      uint16_t &filter_flag,
                                      uint32_t &currlast_count)
    {
        if (filter != nullptr)
            return filter->setDustFilter(threshold, framecount, validpercent, timedf, filterLock, filter_flag, currlast_count);
        else
            return false;
    }

    std::string printSharedPtrAddress(const std::shared_ptr<Frame> &ptr)
    {
        std::ostringstream oss;
        oss << static_cast<const void *>(ptr.get());
        return oss.str();
    }
    void LibHandler::doDustFilterLib(const std::shared_ptr<Frame> &frame,
                                     time_t &lastFrameTime,
                                     std::vector<uint16_t> (&last_distData)[10],
                                     uint32_t &currlast_count)
    {
        // currlast_count = 1;

        if (filter != nullptr)
        {
            // XTLOGINFO(printSharedPtrAddress(frame));
            // std::shared_ptr<IFrame> iframe = frame;
            DustFilterParams params_dustfilter;
            std::shared_ptr<IFrame> iframe = std::dynamic_pointer_cast<IFrame>(frame);

            if (iframe)
            {
                // filter->doDustFilter(iframe, lastFrameTime, last_distData, currlast_count);

                params_dustfilter.currlast_count = currlast_count;
                params_dustfilter.lastFrameTime = lastFrameTime;
                params_dustfilter.frame = iframe;

                for (size_t i = 0; i < 10; ++i)
                {
                    if (params_dustfilter.last_distData[i].data != nullptr)
                    {
                        delete[] params_dustfilter.last_distData[i].data;
                        params_dustfilter.last_distData[i].data = nullptr;
                        params_dustfilter.last_distData[i].size = 0;
                    }
                    params_dustfilter.last_distData[i].data = new uint16_t[last_distData[i].size()];
                    params_dustfilter.last_distData[i].size = last_distData[i].size();
                    std::memcpy(params_dustfilter.last_distData[i].data, last_distData[i].data(), last_distData[i].size() * sizeof(uint16_t));
                }
                filter->doDustFilter(params_dustfilter);

                currlast_count = params_dustfilter.currlast_count;
                lastFrameTime = params_dustfilter.lastFrameTime;
                for (size_t i = 0; i < 10; ++i)
                {
                    if (last_distData[i].size() != params_dustfilter.last_distData[i].size)
                    {
                        last_distData[i].resize(params_dustfilter.last_distData[i].size);
                    }
                    std::memcpy(last_distData[i].data(), params_dustfilter.last_distData[i].data, params_dustfilter.last_distData[i].size * sizeof(uint16_t));
                }
            }
            else
            {
                XTLOGINFO("Failed to cast Frame to IFrame");
            }

            // filter->doDustFilter(frame, lastFrameTime, last_distData, currlast_count);

            for (size_t i = 0; i < 10; ++i)
            {
                if (params_dustfilter.last_distData[i].data != nullptr)
                {
                    delete[] params_dustfilter.last_distData[i].data;
                    params_dustfilter.last_distData[i].data = nullptr;
                    params_dustfilter.last_distData[i].size = 0;
                }
            }
        }
    }


    bool LibHandler::getLoadFlag()
    {
        return bLibLoadSuccess;
    }

}