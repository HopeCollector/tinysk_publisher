﻿/**************************************************************************************
 * Copyright (C) 2022 Xintan Technology Corporation
 *
 * Author: Marco
 ***************************************************************************************/

#include "xtdaemon.h"

#include "xtsdk/utils.h"
#include "xtsdk/xtlogger.h"

// 命令返回状态码对应字符串
const std::string CmdRespStr[]
    = {"ok",     "unsupport", "busy",   "reject", "Unknow", "Unknow",
       "Unknow", "report",    "format", "data",   "csi",    "i2c",
       "temph",  "templ",     "Unknow", "timeout"};

namespace XinTan {

  XtDaemon::XtDaemon(std::string &logtag) : logtagname(logtag) {
    event_callback = nullptr;
    img_callback = nullptr;
    internalEvent_callback = nullptr;

    bDaemonRuning = true;

    threadDaemon = nullptr;
    threadReceiver = nullptr;
    threadUdpReceiver = nullptr;

    threadDaemonRuning = true;
    threadReceiveRuning = true;
    threadUdpReceiveRuning = true;
    bDaemonStarted = true;

    rxedPackageN = 0;
    checkLiveCount = 0;
    isCalibrating = false;

    udpPort = 7687;

    communctNet = new CommnunicationNet(ioService, logtag);
    communctUsb = new CommnunicationUsb(ioService, logtag);

    cartesianTransform = new CartesianTransform(logtag);
    baseFilter = new BaseFilter(logtag);

    cmdresponse = {};
    bwaitCmdreponse = false;
    bwaitCmdreponseok = false;

    commnunication = communctNet;
    isSelNet = false;

    UsingImageThread = true;
    UsingEventThread = true;

    threadImageQueue = nullptr;
    threadEventQueue = nullptr;

    needPointcloud = false;

    stateCode = 0;
    sdkState = STATE_UNSTARTUP;
    devState = DevSTATE_DISCONNECTED;

    WaitFirstConnected = true;
    continueNoRespCount = 0;

    fpscounter = 0;
    fps = 0;
    image_version = 100;

    callbackhasParam = false;

    eventIn = nullptr;
    imgIn = nullptr;
    xtsdk = nullptr;
  }

  XtDaemon::~XtDaemon() {
    bDaemonRuning = false;
    std::this_thread::sleep_for(std::chrono::seconds(1));

    communctNet->disconnect();
    communctNet->closeUdp();
    communctUsb->disconnect();

    std::this_thread::sleep_for(std::chrono::seconds(1));
    delete communctNet;
    delete communctUsb;
    delete cartesianTransform;
    delete baseFilter;
  }

  void XtDaemon::setEvtInternalProcCallbk(
      std::function<void(const std::shared_ptr<CBEventData> &, void *)>
          eventcallback,
      void *psdk) {
    internalEvent_callback = eventcallback;
    xtsdk = psdk;
  }

  void XtDaemon::setCallback(
      std::function<void(const std::shared_ptr<CBEventData> &)> eventcallback,
      std::function<void(const std::shared_ptr<Frame> &)> imgcallback) {
    const std::lock_guard<std::mutex> lock(callbackLock);
    event_callback = eventcallback;
    img_callback = imgcallback;
    eventIn = nullptr;
    imgIn = nullptr;

    callbackhasParam = false;

    std::this_thread::sleep_for(std::chrono::milliseconds(300));
  }

  void XtDaemon::setCallback(
      std::function<void(const std::shared_ptr<CBEventData> &, void *)>
          eventcallback,
      std::function<void(const std::shared_ptr<Frame> &, void *)> imgcallback,
      void *peventIn, void *pimgIn) {
    const std::lock_guard<std::mutex> lock(callbackLock);
    eventIn_callback = eventcallback;
    imgIn_callback = imgcallback;
    eventIn = peventIn;
    imgIn = pimgIn;

    callbackhasParam = true;

    std::this_thread::sleep_for(std::chrono::milliseconds(300));
  }

  void XtDaemon::EventCallback(const std::shared_ptr<CBEventData> &eventdata) {
    if (callbackhasParam == false) {
      if (event_callback != nullptr) event_callback(eventdata);
    } else {
      if (eventIn_callback != nullptr) eventIn_callback(eventdata, eventIn);
    }
  }

  void XtDaemon::ImageCallback(const std::shared_ptr<Frame> &frame) {
    if (callbackhasParam == false) {
      if (img_callback != nullptr) img_callback(frame);
    } else {
      if (imgIn_callback != nullptr) imgIn_callback(frame, imgIn);
    }
  }

  bool XtDaemon::setConnectAddress(std::string connectAddress) {
    XTLOGINFO(connectAddress);
    if (connectAddress == commnunication->address) return true;

    bool lastIsSelNet = isSelNet;

    if (Utils::ipIsValid(connectAddress)) {
      commnunication = communctNet;
      isSelNet = true;
    } else if (Utils::isComport(connectAddress)) {
      commnunication = communctUsb;
      isSelNet = false;
    } else
      return false;

    commnunication->address = connectAddress;

    if (lastIsSelNet != isSelNet) {
      if (lastIsSelNet) {
        communctNet->disconnect();
        communctNet->closeUdp();
      } else
        communctUsb->disconnect();
    }

    if (sdkState != STATE_UNSTARTUP) {
      commnunication->disconnect();
      commnunication->closeUdp();
    }

    return true;
  }

  void XtDaemon::startup() {
    XTLOGINFO("");
    if (threadDaemon == nullptr) {
      threadDaemon = new std::thread(XtDaemon::DaemonFunc, this);
    }

    if (UsingImageThread) {
      if (threadImageQueue == nullptr)
        threadImageQueue = new std::thread(XtDaemon::ImageQueueFunc, this);
    }

    if (UsingEventThread) {
      if (threadEventQueue == nullptr)
        threadEventQueue = new std::thread(XtDaemon::EventQueueFunc, this);
    }
    bDaemonStarted = true;
  }

  void XtDaemon::shutdown() {
    XTLOGINFO("");
    bDaemonStarted = false;

    commnunication->disconnect();
    commnunication->closeUdp();
    std::this_thread::sleep_for(std::chrono::seconds(1));
    updateSdkState(STATE_UNSTARTUP);
  }

  RespResult XtDaemon::transceiveCmd(uint8_t cmdId, XByteArray data,
                                     uint32_t timeoutms) {
    RespResult respResult;

    respResult.ret_code = CmdResp_TIMEOUT;
    if (commnunication->isConnected == false) return respResult;

    const std::lock_guard<std::mutex> lock(cmdLock);
    std::unique_lock<std::mutex> lck(waitLock);

    currentCmdId = cmdId;
    cmdresponse = {};
    bwaitCmdreponse = true;
    bwaitCmdreponseok = false;
    std::cv_status swait;

    //      for(int trys = 0; trys <2; trys++)
    //      {
    //          commnunication->transmitCmd(cmdId, data);
    //          swait =
    //          cmdresp_cond.wait_for(lck,std::chrono::milliseconds(timeoutms));
    //          if(swait == std::cv_status::timeout)
    //          {
    //              if((cmdId == 152)||(cmdId == 153))
    //                  break;
    //              XTLOGINFO("try again cmd "+std::to_string(cmdId));
    //              continue;
    //          }
    //          else
    //              break;
    //      }
    commnunication->transmitCmd(cmdId, data);
    swait = cmdresp_cond.wait_for(lck, std::chrono::milliseconds(timeoutms));
    bwaitCmdreponse = false;

    if (swait != std::cv_status::timeout) {
      respResult.ret_code = (CmdRespCode)(stateCode & 0x0f);
      respResult.data = cmdresponse;

      if (cmdId == 153)  // is calibration cmd
        isCalibrating = true;
      else {
        if (isCalibrating) {
          if (cmdId != 209) isCalibrating = false;
        }
      }
      continueNoRespCount = 0;
    } else {
      if (bwaitCmdreponseok)  // 在notify_all 没有生效时，用于判断是否命令有响应
      {
        bwaitCmdreponseok = false;
        respResult.ret_code = (CmdRespCode)(stateCode & 0x0f);
        respResult.data = cmdresponse;

        continueNoRespCount = 0;
      } else {
        respResult.ret_code = CmdResp_TIMEOUT;
        continueNoRespCount++;
        XTLOGWRN("cmd timeout:" + std::to_string(cmdId));
        if (continueNoRespCount > 3) {
          continueNoRespCount = 0;
          commnunication->disconnect();
        }
      }
    }

    currentCmdId = 0xFF;

    if (respResult.ret_code != CmdResp_OK)
      std::cout << "----Error: Cmd=" + std::to_string(cmdId)
                       + " error= " + CmdRespStr[respResult.ret_code]
                << std::endl;

    return respResult;
  }

  bool XtDaemon::transmitCmd(uint8_t cmdId, XByteArray data) {
    if (commnunication->isConnected == false) return {};
    const std::lock_guard<std::mutex> lock(cmdLock);
    return commnunication->transmitCmd(cmdId, data);
  }

  static int checkTxRxCount = 0;
  void XtDaemon::DaemonFunc(XtDaemon *xtdaemon) {
    while (xtdaemon->bDaemonRuning) {
      if (xtdaemon->threadReceiver == nullptr) {
        xtdaemon->threadReceiver
            = new std::thread(XtDaemon::ReceiveThreadFunc, xtdaemon);
      }
      if ((xtdaemon->isSelNet) && (xtdaemon->threadUdpReceiver == nullptr)) {
        xtdaemon->threadUdpReceiver
            = new std::thread(XtDaemon::UdpReceiveThreadFunc, xtdaemon);
      }

      // 判断通路是否通
      if (xtdaemon->rxedPackageN == 0)
        xtdaemon->checkLiveCount += 1;
      else {
        xtdaemon->checkLiveCount = 0;
        xtdaemon->rxedPackageN = 0;
      }

      if (xtdaemon->commnunication->isConnected) {
        if (xtdaemon->isCalibrating) {
          if (xtdaemon->checkLiveCount > 29) {
            if (xtdaemon->checkLiveCount > 31) {
              xtdaemon->checkLiveCount = 0;
              xtdaemon->updateSdkState(STATE_TXRX_VERIFYING);
            } else
              xtdaemon->transceiveCmd(0, {});  // 再发一次检查连接
          }
        } else {
          if (xtdaemon->checkLiveCount > 2) {
            if (xtdaemon->checkLiveCount > 3) {
              xtdaemon->checkLiveCount = 0;
              xtdaemon->updateSdkState(STATE_TXRX_VERIFYING);
            } else
              xtdaemon->transceiveCmd(0, {});  // 再发一次检查连接
          }
        }
        if (xtdaemon->sdkState == STATE_TXRX_VERIFYING) {
          if (checkTxRxCount > 2) {
            checkTxRxCount = 0;

            XTLOGINFOEXT(xtdaemon->logtagname, "Try Check TXRX");
            xtdaemon->transceiveCmd(0, {});  // 再发一次检查连接
          } else
            checkTxRxCount++;
        }
      }

      if (xtdaemon->isSelNet) {
        if (xtdaemon->communctUsb->isConnected) {
          xtdaemon->communctUsb->disconnect();
        }
      } else {
        if (xtdaemon->communctNet->isConnected) {
          xtdaemon->communctNet->disconnect();
        }
        if (xtdaemon->communctNet->isUdpOpened) {
          xtdaemon->communctNet->closeUdp();
        }
      }

      xtdaemon->fps = xtdaemon->fpscounter;
      xtdaemon->fpscounter = 0;

      std::this_thread::sleep_for(std::chrono::seconds(1));
    }
  }

  void XtDaemon::ReceiveThreadFunc(XtDaemon *xtdaemon) {
    while (xtdaemon->bDaemonRuning) {
      if (xtdaemon->bDaemonStarted) {
        // #检查端口是否打开
        if (xtdaemon->commnunication->isConnected == false) {
          xtdaemon->updateSdkState(STATE_PORTOPENING);

          if (xtdaemon->commnunication->connect()) {
            xtdaemon->currentCmdId = 0;
            xtdaemon->bwaitCmdreponse = false;
            xtdaemon->bwaitCmdreponseok = false;

            xtdaemon->updateSdkState(STATE_TXRX_VERIFYING);
            xtdaemon->transmitCmd(0, {});  // 立即发一次检查连接
          } else
            std::this_thread::sleep_for(std::chrono::seconds(2));

          continue;
        }
        // #收数据包
        CmdResp respdata = xtdaemon->commnunication->receiveCmdPackage();

        if (respdata.cmdid == 0xff)  // 没收到数据包
        {
          if (xtdaemon->commnunication->isConnected == false) {
            xtdaemon->updateSdkState(STATE_TXRX_VERIFYING);
          }
          continue;
        }

        // 收到数据包
        xtdaemon->rxedPackageN += 1;
        std::this_thread::sleep_for(
            std::chrono::milliseconds(1));  // usb读取间隙一下

        uint8_t devstatevalue = (respdata.statecode >> 4) & 0x0f;
        if (devstatevalue <= DevSTATE_ERR_UNKNOW) {
          DevStateCode dev_state = (DevStateCode)devstatevalue;

          if (respdata.ptclVer < 3)
            if (dev_state != xtdaemon->devState)  // device state changed
            {
              xtdaemon->updateDevState(dev_state);
            }
        }

        if (respdata.cmdid != 251)  // 不是帧数据
        {
          if (xtdaemon->currentCmdId == respdata.cmdid)  // 响应命令数据
          {
            if (xtdaemon->bwaitCmdreponse) {
              xtdaemon->bwaitCmdreponse = false;
              xtdaemon->stateCode
                  = static_cast<CmdRespCode>(respdata.statecode);
              xtdaemon->cmdresponse = respdata.data;
              xtdaemon->bwaitCmdreponseok
                  = true;  // 在notify_all 没有生效时，用于判断是否命令有响应
              xtdaemon->cmdresp_cond.notify_all();

              // std::cout << "cmdresp = " +std::to_string(respdata.cmdid) <<
              // std::endl;
            }
          } else  // 上报数据事件
          {
            std::shared_ptr<CBEventData> eventdata
                = std::shared_ptr<CBEventData>(
                    new CBEventData("data", respdata.cmdid, respdata.data,
                                    respdata.statecode & 0x0F));

            if ((xtdaemon->UsingEventThread) && (respdata.cmdid != 157))
              xtdaemon->eventQueue.push(eventdata);
            else {
              const std::lock_guard<std::mutex> lock(xtdaemon->callbackLock);
              xtdaemon->EventCallback(eventdata);
            }

            // xtdaemon->reportEvent("data",respdata.cmdid, respdata.data,
            // respdata.statecode&0x0F);

            if (respdata.cmdid == 153)  // is calibration cmd
              xtdaemon->isCalibrating = true;
          }

          if (xtdaemon->sdkState != STATE_CONNECTED) {
            xtdaemon->updateSdkState(STATE_CONNECTED);
          }
        } else  // frame
        {
          if (respdata.frame != 0) xtdaemon->reportImage(respdata.frame);
        }
      } else {
        if (xtdaemon->commnunication->isConnected)
          xtdaemon->commnunication->disconnect();

        std::this_thread::sleep_for(std::chrono::seconds(1));
      }
    }
  }

  void XtDaemon::UdpReceiveThreadFunc(XtDaemon *xtdaemon) {
    while (xtdaemon->bDaemonRuning) {
      if (xtdaemon->isSelNet) {
        // #检查socket是否打开
        if (xtdaemon->communctNet->isUdpOpened == false) {
          if (xtdaemon->communctNet->openUdp(xtdaemon->udpPort)) {
          } else
            std::this_thread::sleep_for(std::chrono::seconds(2));

          continue;
        }

        // #收数据包
        UdpFrame udpframe = xtdaemon->communctNet->udpReceiveFrame();
        std::shared_ptr<Frame> frame = udpframe.frame;
        if (udpframe.statecode == 0xff)  //(frame == nullptr)
          continue;

        // xtdaemon->fpscounter++;
        xtdaemon->rxedPackageN += 1;

        uint8_t devstatevalue = (udpframe.statecode >> 4) & 0x0f;

        if (xtdaemon->sdkState != STATE_CONNECTED) {
          xtdaemon->updateSdkState(STATE_UDPIMGOK);
        } else {
          if (devstatevalue <= DevSTATE_ERR_UNKNOW) {
            DevStateCode dev_state = (DevStateCode)devstatevalue;
            if ((dev_state > 0)
                && (dev_state != xtdaemon->devState))  // device state changed
            {
              xtdaemon->updateDevState(dev_state);
            }
          }
        }

        xtdaemon->reportImage(frame);
      } else {
        if (xtdaemon->communctNet->isUdpOpened)
          xtdaemon->communctNet->closeUdp();

        std::this_thread::sleep_for(std::chrono::seconds(1));
      }
    }
  }

  void XtDaemon::EventQueueFunc(XtDaemon *xtdaemon) {
    while (xtdaemon->bDaemonRuning) {
      if ((xtdaemon->eventQueue.empty() == false)) {
        const std::shared_ptr<CBEventData> &eventData
            = xtdaemon->eventQueue.front();

        if ((xtdaemon->sdkState == STATE_CONNECTED)
            && (eventData->cmdid == 0xfe))  // 端口打开后第一次连接上设备
          xtdaemon->internalEvent_callback(eventData, xtdaemon->xtsdk);

        {
          const std::lock_guard<std::mutex> lock(xtdaemon->callbackLock);
          xtdaemon->EventCallback(eventData);
        }
        xtdaemon->eventQueue.pop();
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
  }

  void XtDaemon::ImageQueueFunc(XtDaemon *xtdaemon) {
    while (xtdaemon->bDaemonRuning) {
      if (xtdaemon->imageQueue.empty() == false) {
        while (xtdaemon->imageQueue.size() > 1) {
          xtdaemon->imageQueue.pop();
          XTLOGWRNEXT(xtdaemon->logtagname, "frame discard");
          // std::cout << "frame  discard " << std::endl;
        }
        if (xtdaemon->imageQueue.empty() == false) {
          const std::shared_ptr<Frame> &frame = xtdaemon->imageQueue.front();
          frame->timealg[2] = Utils::getTimeStamp();

          //                    xtdaemon->baseFilter->doBaseFilter(frame);
          //                    if(xtdaemon->needPointcloud)
          //                    {
          //                         xtdaemon->cartesianTransform->pcltransCamparm(frame);
          //                    }

          {
            const std::lock_guard<std::mutex> lock(xtdaemon->callbackLock);
            xtdaemon->ImageCallback(frame);
          }
          xtdaemon->imageQueue.pop();
        }
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(30));
    }
  }

  void XtDaemon::updateSdkState(SdkState state) {
    if (sdkState != state) {
      sdkState = state;
      uint8_t cmdid = 0xff;

      if (sdkState == STATE_PORTOPENING) WaitFirstConnected = true;

      if (sdkState == STATE_TXRX_VERIFYING) {
        devState = DevSTATE_DISCONNECTED;
        checkTxRxCount = 0;
      }

      if (sdkState == STATE_UDPIMGOK) devState = DevSTATE_STREAM;

      if (WaitFirstConnected) {
        if (sdkState == STATE_CONNECTED) {
          WaitFirstConnected = false;
          cmdid = 0xfe;
        }
      }

      reportEvent("sdkState", cmdid, {(uint8_t)state});
    }
  }

  void XtDaemon::reportEvent(std::string eventstr, uint8_t cmdid,
                             XByteArray data, uint8_t cmdstate) {
    std::shared_ptr<CBEventData> eventdata = std::shared_ptr<CBEventData>(
        new CBEventData(eventstr, cmdid, data, cmdstate));

    if (UsingEventThread)
      eventQueue.push(eventdata);
    else {
      const std::lock_guard<std::mutex> lock(callbackLock);
      EventCallback(eventdata);
    }
  }

  void XtDaemon::reportImage(const std::shared_ptr<Frame> &frame) {
    fpscounter++;

    if (image_version != frame->frame_version) {
      image_version = frame->frame_version;
      XTLOGINFO("imageversion=" + std::to_string(frame->frame_version));
    }

    if (UsingImageThread) {
      baseFilter->doBaseFilter(frame);
      if (needPointcloud) {
        cartesianTransform->pcltransCamparm(frame);
      }
      imageQueue.push(frame);
    } else {
      const std::lock_guard<std::mutex> lock(callbackLock);
      ImageCallback(frame);
    }
  }

  const std::string devxStateStr[]
      = {"Disconnected", "Init",     "Idle",       "Stream",
         "ErrCSI",       "ErrI2C",   "ErrTEMPL",   "WarnTEMP",
         "tempDownFreq", "ErrTEMPH", "Unknow",     "Unknow",
         "Unknow",       "Unknow",   "Bootloader", "Unknow"};

  void XtDaemon::updateDevState(DevStateCode state) {
    if (devState != state) {
      devState = state;
      reportEvent("devState", 0xFF, {(uint8_t)state});

      XTLOGINFO(devxStateStr[devState]);
    }
  }

  void XtDaemon::doDataFrame(const std::vector<uint8_t> &frameData) {
    int width = frameData[5] | frameData[4] << 8;
    int height = frameData[7] | frameData[6] << 8;

    if ((width > 320) || (width < 1)) return;
    if ((height > 240) || (height < 1)) return;

    int dataType = (int)frameData[1];
    uint16_t Frame_id = frameData[3] | frameData[2] << 8;

    uint32_t frame_temptpos = width * height * 2 + 8;
    if (dataType == Frame::AMPLITUDE)
      frame_temptpos = width * height * 2 * 2 + 8;

    int payloadlen = frameData.size();
    if (payloadlen < (frame_temptpos + 40)) return;

    // std::shared_ptr<Frame> currentFrame = std::shared_ptr<Frame>(new
    // Frame(logtagname,dataType, Frame_id, width, height, 8));
    std::shared_ptr<Frame> currentFrame = std::make_shared<Frame>(
        logtagname, dataType, Frame_id, width, height, 8);
    currentFrame->frame_version = frameData[payloadlen - 1 - 4];
    currentFrame->temperature
        = frameData[frame_temptpos + 1] | frameData[frame_temptpos] << 8;

    if (currentFrame->frame_version == 2) {
      currentFrame->roi_x0 = (uint16_t)frameData[frame_temptpos + 3]
                             | (uint16_t)frameData[frame_temptpos + 2] << 8;
      currentFrame->roi_y0 = (uint16_t)frameData[frame_temptpos + 5]
                             | (uint16_t)frameData[frame_temptpos + 4] << 8;
      if (currentFrame->roi_x0 > 310) currentFrame->roi_x0 = 0;

      if (currentFrame->roi_y0 > 110) currentFrame->roi_y0 = 0;

      currentFrame->binning = frameData[frame_temptpos + 6];
      currentFrame->vcseltemperature
          = frameData[frame_temptpos + 10] | frameData[frame_temptpos + 9] << 8;

      currentFrame->timeStampS
          = Utils::getValueUint48BigEndian(&(frameData[payloadlen - 14 - 4]));
      currentFrame->timeStampNS
          = Utils::getValueUint32BigEndian(&(frameData[payloadlen - 8 - 4]));
      currentFrame->timeStampState = frameData[payloadlen - 4 - 4];
      currentFrame->timeStampType = frameData[payloadlen - 4 - 3];
    } else {
      currentFrame->temperature = (int)frameData[payloadlen - 51]
                                  | (int)frameData[payloadlen - 52] << 8;
      currentFrame->vcseltemperature = 0;
      currentFrame->timeStampState = 0;
      currentFrame->timeStampType = 0;
    }

    currentFrame->sortData(frameData);
    currentFrame->frameData = frameData;

    reportImage(currentFrame);
  }

}  // end namespace XinTan
