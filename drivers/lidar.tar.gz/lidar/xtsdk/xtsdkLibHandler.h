
#ifndef XTSDKLIBHANDLER_H
#define XTSDKLIBHANDLER_H

#include <iostream>
#include <memory>
#include <mutex>

#include "IbaseFilter_lib.h"
#include "xtsdk/frame.h"
#include "xtsdk/xtlogger.h"
// #include "xtsdk/xtsdk.h"

#if defined(_WIN32) || defined(_WIN64)
#  include <windows.h>
typedef HMODULE LibHandle;
#else
#  include <dlfcn.h>

#  include <cstring>
typedef void *LibHandle;
#endif

namespace XinTan {
  extern void xtdlllogger(const char *pfunction, const char *plogstr);
  class LibHandler {
  private:
    std::string lib_path = "";
    // DustFilterParams params_dustfilter;

    LibHandle handle;
    typedef IBaseFilter_lib *(*CreateBaseFilterFunc)(LogFunction);
    typedef void (*DestroyInstanceFunc)(IBaseFilter_lib *);
    // std::shared_ptr<XinTan::BaseFilter_lib> filter;
    IBaseFilter_lib *filter;

    bool bLibLoadSuccess = false;

  public:
    typedef std::shared_ptr<LibHandler> Ptr;
    typedef std::shared_ptr<const LibHandler> ConstPtr;
    std::string &logtagname;
    bool getLoadFlag();
    LibHandler(std::string &logtag);
    ~LibHandler();
    bool setDustFilterLib(uint16_t threshold, uint16_t framecount,
                          uint16_t validpercent, uint16_t timedf,
                          std::mutex &filterLock, uint16_t &filter_flag,
                          uint32_t &currlast_count);
    void doDustFilterLib(const std::shared_ptr<Frame> &frame,
                         time_t &lastFrameTime,
                         std::vector<uint16_t> (&last_distData)[10],
                         uint32_t &currlast_count);
  };
}  // namespace XinTan

#endif  // XTSDKLIBHANDLER_H