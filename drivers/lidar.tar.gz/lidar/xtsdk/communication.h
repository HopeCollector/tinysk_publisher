﻿/**************************************************************************************
 * Copyright (C) 2022 Xintan Technology Corporation
 *
 * Author: Marco
 ***************************************************************************************/
#pragma once

#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "xtsdk/frame.h"

namespace XinTan {

  struct CmdResp {
    uint8_t cmdid;
    uint8_t statecode;
    uint8_t ptclVer;
    XByteArray data;
    std::shared_ptr<Frame> frame;
  };

  struct UdpFrame {
    uint8_t statecode;
    std::shared_ptr<Frame> frame;
  };

  class Commnunication {
  public:
    bool isConnected = false;
    bool isUdpOpened = false;
    bool isConnecting = false;

    std::string address;

    std::mutex opencloseLock;

    virtual bool connect() = 0;
    virtual void disconnect() = 0;
    virtual bool openUdp(uint16_t port = 7687) = 0;
    virtual void closeUdp() = 0;
    virtual bool transmitCmd(uint8_t cmdId, XByteArray data) = 0;

    virtual CmdResp receiveCmdPackage() = 0;
    virtual UdpFrame udpReceiveFrame() = 0;
  };

}  // namespace XinTan
