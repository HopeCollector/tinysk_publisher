﻿/**************************************************************************************
 * Copyright (C) 2022 Xintan Technology Corporation
 *
 * Author: Marco
 ***************************************************************************************/
#pragma once

#include <memory>
#include <mutex>

#include "xtsdk/frame.h"
#include "xtsdkLibHandler.h"

namespace XinTan {

  typedef unsigned int uint;

  // 滤波类型
  enum BaseFilterType {
    FILTER_KALMAN = 0x0001,
    FILTER_AVERAGE = 0x0002,
    FILTER_EDGE = 0x0004,
    FILTER_MEDIAN = 0x0008,
    FILTER_DUST = 0x0010
  };

  class BaseFilter {
  public:
    BaseFilter(std::string &logtag);
    ~BaseFilter();
    std::string &logtagname;

    std::mutex filterLock;

    uint16_t filter_flag;
    void doBaseFilter(const std::shared_ptr<Frame> &frame);

    uint16_t avgsize;
    uint16_t mediansize;
    uint16_t edgeThreshold;
    uint16_t klm_factor_cur;
    uint16_t klm_threshold;
    // uint16_t dustThreshold;
    // uint16_t dustFilterType;
    // int last_dustPercent;

    bool setAvgFilter(uint16_t size);
    bool setKalmanFilter(uint16_t factor, uint16_t threshold,
                         uint16_t timedf = 300);
    bool setEdgeFilter(uint16_t threshold);
    bool setMedianFilter(uint16_t size);
    bool clearAllFilter();

    bool setDustFilter(uint16_t threshold, uint16_t framecount,
                       uint16_t validpercent, uint16_t timedf = 300);
    void doDustFilter(const std::shared_ptr<Frame> &frame);

  private:
    void doMedianFilter(const std::shared_ptr<Frame> &frame);
    void doKalmanFilter(const std::shared_ptr<Frame> &frame);
    void doAverageFilter(const std::shared_ptr<Frame> &frame);
    void doEdgeFilter(const std::shared_ptr<Frame> &frame);
    void doCloudFilter(const std::shared_ptr<Frame> &frame);

    uint32_t timedf_klm;
    uint32_t timedf_dust;
    std::vector<uint16_t> last_distDataKlm;
    uint16_t klm_factor_last;
    time_t lastFrameTime;

    int32_t edgeDetectX;
    int32_t edgeDetectY;

    uint32_t currlast_count;
    // uint32_t dust_maxframe;
    std::vector<uint16_t> last_distData[10];
    // std::vector<uint16_t> last_distBase;
    // std::vector<uint16_t> distMax;
    // std::vector<uint16_t> jumpCount;
    int last_width;
    int last_height;

    LibHandler::Ptr filter_lib;
  };

}  // end namespace XinTan
