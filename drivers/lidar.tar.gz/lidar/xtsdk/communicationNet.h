﻿/**************************************************************************************
* Copyright (C) 2022 Xintan Technology Corporation
*
* Author: Marco
***************************************************************************************/
#pragma once

#include "communication.h"
#include <boost/asio.hpp>
#include <boost/signals2.hpp>

using boost::asio::ip::address;
using boost::asio::ip::tcp;
using boost::asio::ip::udp;

namespace XinTan {

class CommnunicationNet: public Commnunication{

public:
    CommnunicationNet(boost::asio::io_service& ios, std::string & logtag);
    ~CommnunicationNet();
    std::string & logtagname;

    bool connect();
    void disconnect();
    bool openUdp(uint16_t port =7687);
    void closeUdp();
    bool transmitCmd(uint8_t cmdId, XByteArray data);

    CmdResp  receiveCmdPackage();
    UdpFrame udpReceiveFrame();

    tcp::socket socketTcp;
    tcp::endpoint tcpEndpoint;

private:
    tcp::resolver resolver;
    XByteArray tcpRecvPacket;

    udp::socket socketUdp;
    //udp::endpoint udpEndpoint;
    XByteArray udpRecvBuffer;
    XByteArray udpRecvPacket;


    std::shared_ptr<Frame> currentFrame;

    XByteArray data_buffer[3];
    uint32_t data_isUsed[3];
    uint32_t data_count[3];
    uint16_t data_sn[3];
    uint32_t data_size[3];

    bool udppacket(const XByteArray & p, uint8_t & statecode);

};

} //end namespace xintan

