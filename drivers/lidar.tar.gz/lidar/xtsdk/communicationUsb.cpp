﻿/**************************************************************************************
 * Copyright (C) 2022 Xintan Technology Corporation
 *
 * Author: Marco
 ***************************************************************************************/
#include "communicationUsb.h"

#include <iostream>
#include <thread>

#include "xtsdk/utils.h"
#include "xtsdk/xtlogger.h"

namespace XinTan {

  CommnunicationUsb::CommnunicationUsb(boost::asio::io_service &ios,
                                       std::string &logtag)
      : logtagname(logtag),
        serialPort(ios),
        RecvData(XByteArray(4096)),
        usbRecvPacket(XByteArray(4096)),
        data(XByteArray(25 + 320 * 240 * 4 * 2)) {
    isConnected = false;
    address = "";
    isConnecting = false;
  }

  CommnunicationUsb::~CommnunicationUsb() { disconnect(); }

  bool CommnunicationUsb::openUdp(uint16_t port) { return false; }

  void CommnunicationUsb::closeUdp() {}

  UdpFrame CommnunicationUsb::udpReceiveFrame() {
    UdpFrame udpframe;
    return udpframe;
  }

  void openUsbThread(CommnunicationUsb *pComuntUsb) {
    boost::system::error_code error;
    try {
      pComuntUsb->serialPort.open(pComuntUsb->address, error);  // 连接服务
      // std::cout << "usb opened " << std::endl;

    } catch (std::exception &e) {
      std::cout << "openTcpThread:exception " << e.what() << std::endl;
      XTLOGWRNEXT(pComuntUsb->logtagname, "openTcpThread:exception");
    }
    if (error) {
    } else {
#ifdef WIN32
      pComuntUsb->serialPort.set_option(
          boost::asio::serial_port_base::baud_rate(10000000));
      pComuntUsb->serialPort.set_option(
          boost::asio::serial_port_base::character_size(8));
      pComuntUsb->serialPort.set_option(
          boost::asio::serial_port_base::stop_bits(
              boost::asio::serial_port_base::stop_bits::one));
      pComuntUsb->serialPort.set_option(boost::asio::serial_port_base::parity(
          boost::asio::serial_port_base::parity::none));
      pComuntUsb->serialPort.set_option(
          boost::asio::serial_port_base::flow_control(
              boost::asio::serial_port_base::flow_control::none));
#endif
      pComuntUsb->isConnecting = false;
    }
  }

  bool CommnunicationUsb::connect() {
    const std::lock_guard<std::mutex> lock(opencloseLock);
    if (Utils::isComport(address) == false) return false;

    if (isConnected) return true;

    isConnecting = true;

    std::thread openthred(openUsbThread, this);

    for (int i = 0; i < 3; i++) {
      if (isConnecting) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        continue;
      }
      break;
    }

    if (isConnecting) {
      openthred.join();
      return false;
    } else {
      isConnected = true;
      openthred.join();
      // PurgeComm(serialPort.native_handle(),PURGE_RXCLEAR|PURGE_RXABORT);
      return true;
    }
  }
  void CommnunicationUsb::disconnect() {
    const std::lock_guard<std::mutex> lock(opencloseLock);
    if (isConnected == false) return;

    boost::system::error_code error;
    try {
      serialPort.cancel(error);
      serialPort.close(error);  // 关闭串口
      // std::cout << "usb closed " << std::endl;
    } catch (std::exception &e) {
      std::cout << "Usb disconnect:exception " << e.what() << std::endl;
      XTLOGWRN("Usb disconnect:exception ");
    }
    if (error) {
      std::cout << "usb already closed " << std::endl;
      XTLOGWRN("usb already closed ");
    }

    isConnected = false;
  }

  bool CommnunicationUsb::transmitCmd(uint8_t cmdId, XByteArray data) {
    if (isConnected == false) return false;

    uint32_t data_len = (uint32_t)(data.size());
    size_t payload_size = 1 + data_len + 2;

    std::ostringstream os;
    os << static_cast<uint8_t>(0x7E);
    os << static_cast<uint8_t>(0xFF);
    os << static_cast<uint8_t>(0xAA);
    os << static_cast<uint8_t>(0x55);

    os << static_cast<uint8_t>((payload_size >> 24) & 0xff);
    os << static_cast<uint8_t>((payload_size >> 16) & 0xff);
    os << static_cast<uint8_t>((payload_size >> 8) & 0xff);
    os << static_cast<uint8_t>((payload_size >> 0) & 0xff);
    os << static_cast<uint8_t>(cmdId);
    for (uint32_t i = 0; i < data_len; ++i) {
      os << static_cast<uint8_t>(data[i]);
    }

    os << static_cast<uint8_t>(0x00);
    os << static_cast<uint8_t>(0x01);
    os << static_cast<uint8_t>(0xFF);
    os << static_cast<uint8_t>(0x7E);
    os << static_cast<uint8_t>(0x55);
    os << static_cast<uint8_t>(0xAA);

    boost::system::error_code error;
    boost::asio::write(serialPort, boost::asio::buffer(os.str(), os.tellp()),
                       error);
    if (error) {
      std::cout << "cmd wirte error" << std::endl;
      // throw boost::system::system_error(error);

      XTLOGWRN("cmd wirte error ");
      return false;
    }
    return true;
  }

  static time_t firsttime = 0;
  CmdResp CommnunicationUsb::receiveCmdPackage() {
    CmdResp resp;
    resp.cmdid = 0xff;
    resp.frame = 0;
    if (isConnected == false) return resp;

    boost::system::error_code error;
    XByteArray buf_head(10);
    XByteArray buf(500000);

    uint32_t startmark = 0;
    uint32_t endmark = 0;

    uint32_t payloadlen = 0;
    bool receivedPackage = false;
    // 读包头
    size_t len = 0;
    try {
      len = boost::asio::read(serialPort, boost::asio::buffer(buf_head),
                              boost::asio::transfer_exactly(8), error);
    } catch (std::exception &e) {
      std::cout << "Usb read head:exception " << e.what() << std::endl;

      XTLOGWRN("Usb read head:exception");
    }

    if (error) {
      std::cout << "usb head error" << std::endl;
      XTLOGERR("usb head error");
      disconnect();
      return resp;
    }
    startmark = Utils::getValueUint32BigEndian(&(buf_head[0]));
    if (startmark == 0x7EFFAA55) {
      payloadlen = Utils::getValueUint32BigEndian(&(buf_head[4]));
      if ((payloadlen > 2) && (payloadlen < 307200 + 61)) {
        firsttime = Utils::getTimeStamp();
        // 读数据和尾
        try {
          len = boost::asio::read(serialPort, boost::asio::buffer(buf),
                                  boost::asio::transfer_exactly(payloadlen + 4),
                                  error);
        } catch (std::exception &e) {
          std::cout << "Usb read data:exception " << e.what() << std::endl;

          XTLOGWRN("Usb read data:exception");
        }
        if (error) {
          std::cout << "usb data error" << std::endl;
          XTLOGWRN("usb data error");
          disconnect();
          return resp;
        } else {
          buf.resize(len);
          usbRecvPacket = buf;
          endmark = Utils::getValueUint32BigEndian(&(buf[len - 4]));
          if (endmark == 0xFF7E55AA) receivedPackage = true;
        }

      } else
        std::cout << " rxusb err payload " + std::to_string(payloadlen)
                  << std::endl;

    } else {
      // std::cout << " rxusb err head  " << std::endl;
      XTLOGWRN("rxusb err head");
      // 读取遗留
      size_t len = serialPort.read_some(boost::asio::buffer(buf), error);
      if (error) {
        std::cout << "usb rx error" << len << std::endl;
        disconnect();
      }
      return resp;
    }

    if (receivedPackage != true) return resp;

    if (usbRecvPacket.size() < 7) return resp;

    if (payloadlen != (usbRecvPacket.size() - 4)) return resp;

    // 收到一个数据包
    resp.cmdid = usbRecvPacket[0];
    resp.ptclVer = usbRecvPacket[payloadlen - 1];
    resp.statecode = usbRecvPacket[payloadlen - 2];
    if (resp.cmdid != 251)  // 不是Frame
    {
      resp.data.assign(usbRecvPacket.begin() + 1, usbRecvPacket.end() - 6);
      return resp;
    }

    // frame data
    int width = usbRecvPacket[5] | usbRecvPacket[4] << 8;
    int height = usbRecvPacket[7] | usbRecvPacket[6] << 8;

    if ((width > 320) || (width < 1)) return resp;
    if ((height > 240) || (height < 1)) return resp;

    int dataType = (int)usbRecvPacket[1];
    uint16_t Frame_id = usbRecvPacket[3] | usbRecvPacket[2] << 8;

    uint32_t frame_temptpos = width * height * 2 + 8;
    if (dataType == Frame::AMPLITUDE)
      frame_temptpos = width * height * 2 * 2 + 8;

    if (payloadlen < (frame_temptpos + 40)) return resp;

    // currentFrame = std::shared_ptr<Frame>(new Frame(logtagname,dataType,
    // Frame_id, width, height, 8));
    currentFrame = std::make_shared<Frame>(logtagname, dataType, Frame_id,
                                           width, height, 8);
    currentFrame->frame_version = usbRecvPacket[payloadlen - 1];
    currentFrame->temperature = usbRecvPacket[frame_temptpos + 1]
                                | usbRecvPacket[frame_temptpos] << 8;

    if (currentFrame->frame_version == 2) {
      currentFrame->roi_x0 = (uint16_t)usbRecvPacket[frame_temptpos + 3]
                             | (uint16_t)usbRecvPacket[frame_temptpos + 2] << 8;
      currentFrame->roi_y0 = (uint16_t)usbRecvPacket[frame_temptpos + 5]
                             | (uint16_t)usbRecvPacket[frame_temptpos + 4] << 8;
      if (currentFrame->roi_x0 > 310) currentFrame->roi_x0 = 0;

      if (currentFrame->roi_y0 > 110) currentFrame->roi_y0 = 0;

      currentFrame->binning = usbRecvPacket[frame_temptpos + 6];
      currentFrame->vcseltemperature = usbRecvPacket[frame_temptpos + 10]
                                       | usbRecvPacket[frame_temptpos + 9] << 8;

      currentFrame->timeStampS
          = Utils::getValueUint48BigEndian(&(usbRecvPacket[payloadlen - 14]));
      currentFrame->timeStampNS
          = Utils::getValueUint32BigEndian(&(usbRecvPacket[payloadlen - 8]));
      currentFrame->timeStampState = usbRecvPacket[payloadlen - 4];
      currentFrame->timeStampType = usbRecvPacket[payloadlen - 3];

    } else {
      currentFrame->temperature = (int)usbRecvPacket[payloadlen - 51]
                                  | (int)usbRecvPacket[payloadlen - 52] << 8;
      currentFrame->vcseltemperature = 0;
      currentFrame->timeStampState = 0;
      currentFrame->timeStampType = 0;
    }

    currentFrame->timealg[0] = firsttime;
    currentFrame->timealg[1] = Utils::getTimeStamp();

    currentFrame->frameData.assign(usbRecvPacket.begin(), usbRecvPacket.end());
    currentFrame->sortData(currentFrame->frameData);
    resp.frame = currentFrame;
    return resp;
  }

}  // end namespace XinTan
