﻿/**************************************************************************************
 * Copyright (C) 2022 Xintan Technology Corporation
 *
 * Author: Marco
 ***************************************************************************************/
#pragma once

#include <mutex>
#include <opencv2/opencv.hpp>

#include "xtsdk/frame.h"

namespace XinTan {

  typedef unsigned int uint;

  class CartesianTransform {
  public:
    CartesianTransform(std::string &logtag);
    ~CartesianTransform();
    std::string &logtagname;

    CamParameterS camParams;
    double ocX, ocY;
    std::vector<cv::Point2f> outputUndistortedPoints;
    std::vector<bool> outputUndistortedPointsDeled;
    bool bPointsCornerCut;
    uint16_t cutMinAmp;
    int chamferpixels;
    bool hasparam;
    int cutcornervalue;
    int pointout_coord;

    std::mutex camparams_mutex;

    bool bisM60;
    bool hmirror, vmirror;
    void setTransMirror(bool hmirror0, bool vmirror0);
    void setcutcorner(uint32_t cutvalue);

    void maptable(CamParameterS &camparams);
    void pcltransCamparm(const std::shared_ptr<Frame> &frame);

    void undistort(float x, float y, float *out_x, float *out_y);
  };

}  // end namespace XinTan
