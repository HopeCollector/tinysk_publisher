﻿/**************************************************************************************
* Copyright (C) 2022 Xintan Technology Corporation
*
* Author: Marco
***************************************************************************************/
#pragma once

#include <string>
#include <ctime>

namespace XinTan {

class Utils{

public:

	static bool ipIsValid(std::string ipaddress);
	static bool isMacValid(std::string macaddress);
    static int macstr_parse(const char *point, uint8_t result[6]);
    static int ipstr_parse(const char *point, uint8_t result[6]);

	static bool isComport(std::string ipaddress);
	
	static time_t getTimeStamp();
    static std::string getTimeStr();

    static std::string getCurrentProgramDir();


    static uint16_t getValueUint16BigEndian(const uint8_t *buffer);

    static uint32_t getValueUint32BigEndian(const uint8_t *buffer);

    static uint64_t getValueUint64BigEndian(const uint8_t *buffer);
    static uint64_t getValueUint48BigEndian(const uint8_t *buffer);

    static void setValueUint16BigEndian(uint8_t *buffer, const uint16_t value);
    static void setValueUint32BigEndian(uint8_t *buffer, const uint32_t value);
    static void setValueUint64BigEndian(uint8_t *buffer, const uint64_t value);

    static void setValueUint32LittleEndian(uint8_t *buffer, const uint32_t value);

    static void setStrBigEndian(uint8_t *buffer, const char * pdata, const uint32_t size);


    static std::string getHostIp();
};

} //end namespace XinTan
