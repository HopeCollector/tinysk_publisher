﻿#pragma once
#include <cstring>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>

#include "xtsdk/Iframe.h"

namespace XinTan {
  // typedef void (*LogFunction)(const std::string& function, const std::string&
  // logstr);
  typedef void (*LogFunction)(const char *pfunction, const char *plogstr);

  // extern LogFunction g_LogFunction;

  struct DynamicArray {
    uint16_t *data;
    size_t size;

    DynamicArray() : data(nullptr), size(0) {}

    ~DynamicArray() {
      if (data) {
        delete[] data;
        data = nullptr;  // 确保在释放后将指针置空
        size = 0;
      }
    }

    // 拷贝构造函数
    DynamicArray(const DynamicArray &other) : data(nullptr), size(0) {
      if (other.size > 0) {
        data = new uint16_t[other.size];
        size = other.size;
        std::memcpy(data, other.data, size * sizeof(uint16_t));
      }
    }

    // 拷贝赋值操作符
    DynamicArray &operator=(const DynamicArray &other) {
      if (this != &other) {
        if (data) {
          delete[] data;
          data = nullptr;
          size = 0;
        }

        if (other.size > 0) {
          data = new uint16_t[other.size];
          size = other.size;
          std::memcpy(data, other.data, size * sizeof(uint16_t));
        }
      }
      return *this;
    }

    // 移动构造函数
    DynamicArray(DynamicArray &&other) noexcept
        : data(other.data), size(other.size) {
      other.data = nullptr;
      other.size = 0;
    }

    // 移动赋值操作符
    DynamicArray &operator=(DynamicArray &&other) noexcept {
      if (this != &other) {
        if (data) {
          delete[] data;
        }

        data = other.data;
        size = other.size;
        other.data = nullptr;
        other.size = 0;
      }
      return *this;
    }
  };
  struct DustFilterParams {
    std::shared_ptr<IFrame> frame;
    time_t lastFrameTime;
    uint32_t currlast_count;
    // std::vector<uint16_t> last_distData[10];
    DynamicArray last_distData[10];
  };

  class IBaseFilter_lib {
  public:
    virtual ~IBaseFilter_lib() = default;

    virtual bool setDustFilter(uint16_t threshold, uint16_t framecount,
                               uint16_t validpercent, uint16_t timedf,
                               std::mutex &filterLock, uint16_t &filter_flag,
                               uint32_t &currlast_count)
        = 0;
    // virtual void doDustFilter(const std::shared_ptr<IFrame> &frame,
    //                           time_t &lastFrameTime,
    //                           std::vector<uint16_t> (&last_distData)[10],
    //                           uint32_t &currlast_count) = 0;
    virtual void doDustFilter(DustFilterParams &params) = 0;
  };

#if defined(_WIN32) || defined(_WIN64)
#  define EXPORT __declspec(dllexport)
#else
#  define EXPORT
#endif

  extern "C" {
  EXPORT IBaseFilter_lib *createInstance(LogFunction logFunction);
  EXPORT void destroyInstance(IBaseFilter_lib *instance);
  }
}  // namespace XinTan
