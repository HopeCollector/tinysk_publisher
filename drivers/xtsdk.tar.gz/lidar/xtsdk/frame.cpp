﻿/**************************************************************************************
 * Copyright (C) 2022 Xintan Technology Corporation
 *
 * Author: Marco
 ***************************************************************************************/
#include "xtsdk/frame.h"

namespace XinTan {

  uint16_t g_xbinning = 0;
  uint16_t g_ybinning = 0;

  float g_reflectcoef = 0.0;

  Frame::Frame(std::string &logtag_, uint16_t dataType_, uint64_t frame_id_,
               uint16_t width_, uint16_t height_, uint16_t payloadOffset)
      : logtagname(logtag_),
        dataType(dataType_),
        width(width_),
        height(height_),
        pixelDataOffset(payloadOffset),
        px_size(sizeof(uint16_t)),
        frame_id(frame_id_),
        distData(std::vector<uint16_t>(width * height)),      // 16 bit
        amplData(std::vector<uint16_t>(width * height)),      // 16 bit
        reflectivity(std::vector<uint16_t>(width * height)),  // 16 bit
        rawdistData(std::vector<uint16_t>(width * height))    // 16 bit

  {
    hasPointcloud = false;
    for (int i = 0; i < 6; i++) timealg[i] = 0;

    frame_version = 0;
    roi_x0 = 0;
    roi_y0 = 0;
    binning = 0;
    dust_percent = -1;
    needxiacaiyang = true;

    orgwidth = width;
    orgheight = height;

    xbinning = 1;
    ybinning = 1;

    if (g_xbinning > 1) xbinning = g_xbinning;

    if (g_ybinning > 1) ybinning = g_ybinning;
  }

  // const std::vector<uint8_t>& Frame::getFrameData()   { return frameData; }
  const uint16_t Frame::getDistData(const size_t &index) {
    // XTLOGINFO("size inside: " + std::to_string(distData.size()));
    if (index < distData.size() - 1) {
      return distData[index];
    }
    return 0;
  }
  const int Frame::getDistDataSize() { return distData.size(); }
  // const std::vector<uint16_t>& Frame::getAmplData()   { return amplData; }
  // const std::vector<uint16_t>& Frame::getReflectivity()   { return
  // reflectivity; } const std::vector<XtPointXYZI>& Frame::getPoints()   {
  // return points; } const std::vector<uint16_t>& Frame::getRawDistData()   {
  // return rawdistData; } const time_t* Frame::getTimeAlg()   { return
  // const_cast<time_t*>(timealg); }

  uint8_t Frame::getFrameVersion() { return frame_version; }
  uint16_t Frame::getPixelDataOffset() { return pixelDataOffset; }
  uint64_t Frame::getFrameId() { return frame_id; }
  uint16_t Frame::getDataType() { return dataType; }
  uint16_t Frame::getWidth() { return width; }
  uint16_t Frame::getHeight() { return height; }
  uint32_t Frame::getPxSize() { return px_size; }
  uint16_t Frame::getRoiX0() { return roi_x0; }
  uint16_t Frame::getRoiY0() { return roi_y0; }
  uint8_t Frame::getBinning() { return binning; }
  uint64_t Frame::getTimeStampS() { return timeStampS; }
  uint32_t Frame::getTimeStampNS() { return timeStampNS; }
  uint8_t Frame::getTimeStampState() { return timeStampState; }
  uint8_t Frame::getTimeStampType() { return timeStampType; }
  int16_t Frame::getTemperature() { return temperature; }
  int16_t Frame::getVcselTemperature() { return vcseltemperature; }
  uint32_t Frame::getDustPercent() { return dust_percent; }
  bool Frame::getNeedXiaCaiYang() { return needxiacaiyang; }
  uint16_t Frame::getXBinning() { return xbinning; }
  uint16_t Frame::getYBinning() { return ybinning; }
  uint16_t Frame::getOrgWidth() { return orgwidth; }
  uint16_t Frame::getOrgHeight() { return orgheight; }
  bool Frame::getHasPointCloud() { return hasPointcloud; }

  void Frame::setFrameId(uint64_t id) { frame_id = id; }
  void Frame::setTimeStampS(uint64_t ts) { timeStampS = ts; }
  void Frame::setDistdataIndex(const size_t &index, const uint16_t &data) {
    if (index < distData.size() - 1) {
      distData[index] = data;
    }
  };
  void Frame::setDustPercent(uint32_t data) { dust_percent = data; };

  void Frame::sortData(const XByteArray &data) {
    int i, offset, mirrori;

    if (dataType == Frame::AMPLITUDE) {  // distance + amplitude

      uint32_t ampvalue = 0;
      float dist2value = 0;
      float reflctValue = 0;
      int sz = orgwidth * orgheight;
      for (i = 0; i < sz; i++) {
        offset = pixelDataOffset + i * 4;
        //            distData[i]   = data[offset + 1] << 8 | data[offset];
        //            amplData[i]   = data[offset + 3] << 8 | data[offset + 2];
        mirrori = (i / orgwidth) * orgwidth + orgwidth - 1 - i % orgwidth;
        distData[mirrori] = data[offset + 1] << 8 | data[offset];
        amplData[mirrori] = data[offset + 3] << 8 | data[offset + 2];

        // 计算反射率
        if (g_reflectcoef > 0.0) {
          ampvalue = amplData[mirrori];
          dist2value = distData[mirrori];
          if ((ampvalue < 60000) && (dist2value < 60000) && (dist2value > 0)) {
            dist2value = dist2value / 1000;        // 转换为单位米
            dist2value = dist2value * dist2value;  // 距离的平方
            reflctValue = (ampvalue * g_reflectcoef) * dist2value;
            //                    if(reflctValue > 255)
            //                        reflctValue = 255;

            reflectivity[mirrori] = reflctValue;
          } else
            reflectivity[mirrori] = 0;
        }
      }

      if (needxiacaiyang) {
        needxiacaiyang = false;

        if (xbinning > 1) width = width / xbinning;

        if (ybinning > 1) height = height / ybinning;
      }

      int xiapos = 0;
      if ((xbinning + ybinning) > 2) {
        for (uint16_t h = 0; h < height; h++) {
          for (uint16_t j = 0; j < width; j++) {
            uint32_t pos = h * ybinning * orgwidth + j * xbinning;

            int youxiaocount = 0;
            int youxiaoampcount = 0;
            uint32_t sumdist = 0;
            uint32_t sumamp = 0;
            for (int y = 0; y < ybinning; y++)
              for (int x = 0; x < xbinning; x++) {
                if (distData[pos + y * orgwidth + x] < 64000) {
                  sumdist += distData[pos + y * orgwidth + x];
                  youxiaocount++;
                }
                if (amplData[pos + y * orgwidth + x] < 3000) {
                  sumamp += amplData[pos + y * orgwidth + x];
                  youxiaoampcount++;
                }
              }

            if (youxiaocount > 0)
              sumdist = sumdist / youxiaocount;
            else
              sumdist = distData[pos];

            if (youxiaoampcount > 0)
              sumamp = sumamp / youxiaoampcount;
            else
              sumamp = amplData[pos];

            distData[xiapos] = sumdist;
            amplData[xiapos] = sumamp;

            // 计算反射率
            if (g_reflectcoef > 0.0) {
              ampvalue = sumamp;
              dist2value = sumdist;
              if ((ampvalue < 60000) && (dist2value < 60000)
                  && (dist2value > 0)) {
                dist2value = dist2value / 1000;        // 转换为单位米
                dist2value = dist2value * dist2value;  // 距离的平方
                reflctValue = (ampvalue * g_reflectcoef) * dist2value;
                //                            if(reflctValue > 255)
                //                                reflctValue = 255;

                reflectivity[xiapos] = reflctValue;
              } else
                reflectivity[xiapos] = 0;
            }

            xiapos++;
          }
        }
      }
    } else if (dataType == Frame::DISTANCE) {  // distance

      int sz = width * height;
      for (i = 0; i < sz; i++) {
        offset = pixelDataOffset + i * 2;
        // distData[i]   = data[offset + 1] << 8 | data[offset];

        mirrori = (i / width) * width + width - 1 - i % width;
        distData[mirrori] = data[offset + 1] << 8 | data[offset];

        amplData[mirrori] = 0;
        reflectivity[mirrori] = 0;
      }
    } else if (dataType == Frame::GRAYSCALE) {  // grayscale

      int sz = width * height;
      for (i = 0; i < sz; i++) {
        offset = pixelDataOffset + i * 2;
        // amplData[i]   = data[offset + 1] << 8 | data[offset];

        mirrori = (i / width) * width + width - 1 - i % width;
        amplData[mirrori] = data[offset + 1] << 8 | data[offset];

        distData[mirrori] = 0;
        reflectivity[mirrori] = 0;
      }
    }

    rawdistData = distData;
  }

}  // end namespace XinTan
