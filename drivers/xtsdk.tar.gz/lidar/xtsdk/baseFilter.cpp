﻿/**************************************************************************************
 * Copyright (C) 2022 Xintan Technology Corporation
 *
 * Author: Marco
 ***************************************************************************************/
#include "basefilter.h"

#include <bitset>
#include <opencv2/opencv.hpp>

#include "xtsdk/utils.h"
#include "xtsdk/xtlogger.h"

using namespace cv;

static const int AMPLITUDE_LOW = 64001;
namespace XinTan {

  BaseFilter::BaseFilter(std::string &logtag)
      : last_distDataKlm(std::vector<uint16_t>(320 * 240 + 100)),
        //   last_distBase(std::vector<uint16_t>(320 * 240 + 100)),
        //   distMax(std::vector<uint16_t>(320 * 240 + 100)),
        //   jumpCount(std::vector<uint16_t>(320 * 240 + 100)),
        logtagname(logtag) {
    filter_flag = 0;
    avgsize = 0;
    mediansize = 0;
    edgeThreshold = 0;
    klm_factor_cur = 0;
    klm_threshold = 0;
    lastFrameTime = 0;
    currlast_count = 0;
    timedf_klm = 300;
    timedf_dust = 300;

    // dustThreshold = 0;
    // dustFilterType = 0;
    // dust_maxframe = 3;
    // last_dustPercent = -1;

    last_width = 0;
    last_height = 0;

    filter_lib = std::make_shared<LibHandler>(logtag);
  }

  BaseFilter::~BaseFilter() {}

  bool BaseFilter::setAvgFilter(uint16_t size) {
    const std::lock_guard<std::mutex> lock(filterLock);
    filter_flag &= ~FILTER_AVERAGE;
    XTLOGINFO(std::to_string(size));

    if (size == 0) {
      return true;
    }

    avgsize = size;
    filter_flag |= FILTER_AVERAGE;
    return true;
  }

  bool BaseFilter::setKalmanFilter(uint16_t factor, uint16_t threshold,
                                   uint16_t timedf) {
    const std::lock_guard<std::mutex> lock(filterLock);
    filter_flag &= ~FILTER_KALMAN;
    XTLOGINFO(std::to_string(factor) + " " + std::to_string(threshold));

    timedf_klm = timedf;
    if ((factor == 0) || (threshold == 0) || (factor > 1000)
        || (threshold > 1000)) {
      return true;
    }

    klm_factor_cur = factor;
    klm_factor_last = 1000 - klm_factor_cur;
    klm_threshold = threshold;
    filter_flag |= FILTER_KALMAN;
    return true;
  }

  bool BaseFilter::setEdgeFilter(uint16_t threshold) {
    const std::lock_guard<std::mutex> lock(filterLock);
    filter_flag &= ~FILTER_EDGE;
    XTLOGINFO(std::to_string(threshold));

    if (threshold == 0) {
      return true;
    }

    edgeThreshold = threshold;
    filter_flag |= FILTER_EDGE;
    return true;
  }

  bool BaseFilter::setMedianFilter(uint16_t size)  // 必须是奇数
  {
    const std::lock_guard<std::mutex> lock(filterLock);
    filter_flag &= ~FILTER_MEDIAN;
    XTLOGINFO(std::to_string(size));

    if ((size != 3) && (size != 5)) {
      return true;
    }
    mediansize = size;
    filter_flag |= FILTER_MEDIAN;
    return true;
  }

  bool BaseFilter::setDustFilter(uint16_t threshold, uint16_t framecount,
                                 uint16_t validpercent, uint16_t timedf) {
    // const std::lock_guard<std::mutex> lock(filterLock);
    // filter_flag &= ~FILTER_DUST;
    // XTLOGINFO(std::to_string(threshold) + " " + std::to_string(framecount) +
    // " " + std::to_string(timedf)); timedf_dust = timedf;

    // if ((threshold == 0) || (framecount < 2) || (framecount > 9))
    // {
    //     return true;
    // }

    // dustFilterType = threshold / 10000;
    // dustThreshold = threshold % 10000;

    // dust_validpercent = validpercent;

    // //        std::cout << "dustFilterType=" <<
    // std::to_string(dustFilterType) << std::endl;
    // //        std::cout << "dustThreshold=" << std::to_string(dustThreshold)
    // << std::endl;

    // dust_maxframe = framecount;
    // currlast_count = 0;
    // filter_flag |= FILTER_DUST;

    // return true;
    if (filter_lib->getLoadFlag()) {
      XTLOGINFO(std::to_string(threshold) + " " + std::to_string(framecount)
                + " " + std::to_string(timedf));
      return filter_lib->setDustFilterLib(threshold, framecount, validpercent,
                                          timedf, filterLock, filter_flag,
                                          currlast_count);
    } else {
      std::cout << "SDK LIB LOAD FAILED: set dust" << std::endl;
      return false;
    }
  }

  bool BaseFilter::clearAllFilter() {
    const std::lock_guard<std::mutex> lock(filterLock);
    XTLOGINFO("");
    filter_flag = 0;
    return true;
  }

  void medianBlur2(const cv::Mat &src, cv::Mat &dst, int ksize) {
    // 检查输入是否有效
    if (ksize % 2 == 0 || ksize < 1) {
      std::cerr << "Kernel size should be odd and greater than 1" << std::endl;

      dst = src.clone();
      return;  // src;
    }

    // 定义边界扩展大小
    int border = ksize / 2;
    cv::Mat padded;
    cv::copyMakeBorder(src, padded, border, border, border, border,
                       cv::BORDER_REPLICATE);

    // 输出图像
    dst = src.clone();

    // 遍历图像像素
    for (int i = border; i < padded.rows - border; ++i) {
      for (int j = border; j < padded.cols - border; ++j) {
        // 获取窗口内的像素值
        uint16_t rawdist = padded.at<uint16_t>(i, j);
        std::vector<uint16_t> window;
        for (int x = -border; x <= border; ++x) {
          for (int y = -border; y <= border; ++y) {
            uint16_t dist = padded.at<uint16_t>(i + x, j + y);
            if ((dist < 64000) && (dist > 0)) window.push_back(dist);
          }
        }
        if (window.size() < 1) continue;

        // 对窗口内的像素排序并取中值
        std::nth_element(window.begin(), window.begin() + window.size() / 2,
                         window.end());
        uint16_t mediandist = window[window.size() / 2];
        if (rawdist > 64000)  // 无效点不补
          dst.at<uint16_t>(i - border, j - border) = rawdist;
        else  // 有效点用中值
          dst.at<uint16_t>(i - border, j - border) = mediandist;
      }
    }

    return;  // dst;
  }

  void BaseFilter::doMedianFilter(const std::shared_ptr<Frame> &frame) {
    if (frame->dataType != Frame::GRAYSCALE) {
      Mat depth_img(frame->width, frame->height, CV_16UC1);
      for (int y = 0; y < frame->height; y++)
        for (int x = 0; x < frame->width; x++) {
          depth_img.at<uint16_t>(x, y) = frame->distData[y * frame->width + x];
        }

      Mat filtered_img;
      medianBlur2(depth_img, filtered_img, mediansize);

      for (int y = 0; y < frame->height; y++)
        for (int x = 0; x < frame->width; x++) {
          frame->distData[y * frame->width + x]
              = filtered_img.at<uint16_t>(x, y);
        }
    } else {
      Mat depth_img(frame->width, frame->height, CV_16UC1);
      for (int y = 0; y < frame->height; y++)
        for (int x = 0; x < frame->width; x++) {
          depth_img.at<uint16_t>(x, y) = frame->amplData[y * frame->width + x];
        }

      Mat filtered_img;
      medianBlur(depth_img, filtered_img, mediansize);

      for (int y = 0; y < frame->height; y++)
        for (int x = 0; x < frame->width; x++) {
          frame->amplData[y * frame->width + x] = depth_img.at<uint16_t>(x, y);
        }
    }
  }

  void BaseFilter::doKalmanFilter(const std::shared_ptr<Frame> &frame) {
    bool bfilterstart = false;
    time_t frameTime = Utils::getTimeStamp();
    if (abs(frameTime - lastFrameTime) < 300)  // 300ms
      bfilterstart = true;
    lastFrameTime = frameTime;

    if (frame->dataType != Frame::GRAYSCALE) {
      int i = 0;
      uint32_t result = 0;
      uint32_t actValue;
      uint32_t lastValue;
      for (int y = 0; y < frame->height; y++)
        for (int x = 0; x < frame->width; x++, i++) {
          actValue = frame->distData[i];
          if (bfilterstart) {
            lastValue = last_distDataKlm[i];
            if ((actValue > 0) && (actValue < 64000) && (lastValue > 0)
                && (lastValue < 64000)) {
              int32_t diff = actValue - lastValue;

              if ((abs(diff) < klm_threshold) || (klm_factor_cur < 51))
              // if(abs(diff) < klm_threshold)
              {
                result = (((actValue * klm_factor_cur)
                           + (lastValue * klm_factor_last))
                          / 1000);
              } else
                result = frame->distData[i];

              frame->distData[i] = result;
              last_distDataKlm[i] = result;
            } else {
              last_distDataKlm[i] = actValue;
            }
          }
        }
    }
  }

  void BaseFilter::doAverageFilter(const std::shared_ptr<Frame> &frame) {}

  void BaseFilter::doEdgeFilter(const std::shared_ptr<Frame> &frame) {
    if (frame->dataType != Frame::GRAYSCALE) {
      uint32_t curValue;
      uint32_t preValue;
      uint32_t resultValue;
      int diffcount = 0;
      int distThreshold = edgeThreshold;
      int nearbyPosOffset[8];
      nearbyPosOffset[0] = -frame->width - 1;  // 左上角
      nearbyPosOffset[1] = -frame->width;      // 上方
      nearbyPosOffset[2] = -frame->width + 1;  // 右上角
      nearbyPosOffset[3] = -1;                 // 左边
      nearbyPosOffset[4] = +1;                 // 右边
      nearbyPosOffset[5] = frame->width - 1;   // 左下角
      nearbyPosOffset[6] = frame->width;       // 下方
      nearbyPosOffset[7] = frame->width + 1;   // 右下角

      for (int y = 1; y < (frame->height - 1); y++)   // 排除像素四边
        for (int x = 1; x < (frame->width - 1); x++)  // 排除像素四边
        {
          curValue = frame->distData[y * frame->width + x];
          resultValue = curValue;
          if (curValue < 64000) {
            diffcount = 0;
            distThreshold
                = (edgeThreshold * curValue) / 2000;  // 按距离比例适应阈值
            int curpos = y * frame->width + x;
            for (int i = 0; i < 8; i++) {
              preValue = frame->distData[curpos + nearbyPosOffset[i]];

              if (preValue < 64000) {
                int diff = preValue - curValue;

                if (abs(diff) > distThreshold) diffcount++;
              } else
                diffcount++;
            }
            if (diffcount > 5) resultValue = 64008;
          }
          frame->distData[y * frame->width + x] = resultValue;
        }
    }
  }
  std::string toBinaryString(int n, int bitWidth = 32) {
    std::bitset<32> binary(n);  // 使用 bitset 表示二进制
    return binary.to_string().substr(32 - bitWidth,
                                     bitWidth);  // 截取指定宽度的二进制字符串
  }
  void BaseFilter::doBaseFilter(const std::shared_ptr<Frame> &frame) {
    const std::lock_guard<std::mutex> lock(filterLock);

    if ((last_width != frame->width) || (last_height != frame->height))
      currlast_count = 0;

    if (filter_flag & FILTER_DUST) {
      doDustFilter(frame);
    }

    if (filter_flag & FILTER_EDGE) doEdgeFilter(frame);

    if (filter_flag & FILTER_MEDIAN) doMedianFilter(frame);

    if (filter_flag & FILTER_AVERAGE) doAverageFilter(frame);

    if (filter_flag & FILTER_KALMAN) doKalmanFilter(frame);

    if ((last_width != frame->width) || (last_height = frame->height))
      last_distData[currlast_count] = frame->distData;

    last_width = frame->width;
    last_height = frame->height;
  }

  void BaseFilter::doDustFilter(const std::shared_ptr<Frame> &frame) {
    if (filter_lib->getLoadFlag()) {
      filter_lib->doDustFilterLib(frame, lastFrameTime, last_distData,
                                  currlast_count);
    } else {
      std::cout << "SDK LIB LOAD FAILED: do dust" << std::endl;
      return;
    }
  }

}  // end namespace XinTan
