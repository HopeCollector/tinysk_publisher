﻿/**************************************************************************************
 * Copyright (C) 2022 Xintan Technology Corporation
 *
 * Author: Marco
 ***************************************************************************************/
#include "communicationNet.h"

#include <iostream>
#include <thread>

#include "xtsdk/utils.h"
#include "xtsdk/xtlogger.h"

#define UDP_HEADER_OFFSET 20

namespace XinTan {

  CommnunicationNet::CommnunicationNet(boost::asio::io_service &ios,
                                       std::string &logtag)
      : logtagname(logtag),
        socketTcp(ios),
        tcpEndpoint(boost::asio::ip::address_v4::from_string("192.168.0.101"),
                    7787),
        resolver(ios),
        tcpRecvPacket(XByteArray(4096)),
        socketUdp(ios),
        // udpEndpoint(udp::v4(), 7687),
        udpRecvBuffer(XByteArray(4096)),
        udpRecvPacket(XByteArray(4096)) {
    address = "";
    isConnected = false;
    isConnecting = false;
    isUdpOpened = false;
    for (int i = 0; i < 3; i++) {
      data_buffer[i] = XByteArray(80 + 320 * 240 * 4 * 2);
      data_isUsed[i] = 0;
      data_count[i] = 0;
      data_sn[i] = 0;
      data_size[i] = 0;
    }
  }

  CommnunicationNet::~CommnunicationNet() {
    disconnect();
    closeUdp();
  }

  void openTcpThread(CommnunicationNet *pComuntNet) {
    XTLOGINFOEXT(pComuntNet->logtagname, "");
    boost::system::error_code error;
    pComuntNet->socketTcp.connect(pComuntNet->tcpEndpoint, error);  // 连接服务
    if (error) {
      XTLOGWRNEXT(pComuntNet->logtagname, "error");
    } else
      pComuntNet->isConnecting = false;
  }

  bool CommnunicationNet::connect() {
    const std::lock_guard<std::mutex> lock(opencloseLock);
    if (Utils::ipIsValid(address) == false) return false;

    if (isConnected || isConnecting) return true;
    boost::asio::ip::address_v4 ipaddress
        = boost::asio::ip::address_v4::from_string(address);

    tcpEndpoint.address(ipaddress);

    isConnecting = true;
    std::thread openthred(openTcpThread, this);

    for (int i = 0; i < 3; i++) {
      if (isConnecting) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        continue;
      }
      break;
    }

    if (isConnecting) {
      socketTcp.close();
      openthred.join();

      std::this_thread::sleep_for(std::chrono::seconds(1));
      isConnecting = false;
      return false;
    } else {
      isConnected = true;
      openthred.join();
      XTLOGWRN("tcp connected");
      return true;
    }
  }
  void CommnunicationNet::disconnect() {
    const std::lock_guard<std::mutex> lock(opencloseLock);
    if (isConnected == false) return;

    boost::system::error_code error;
    socketTcp.shutdown(boost::asio::ip::tcp::socket::shutdown_both, error);
    if (!error) {
      XTLOGWRN("error");
      socketTcp.close(error);
      std::cout << "tcp closed " << std::endl;
    }

    isConnected = false;
  }
  bool CommnunicationNet::openUdp(uint16_t port) {
    const std::lock_guard<std::mutex> lock(opencloseLock);
    if (isUdpOpened) return true;

    XTLOGWRN("");
    try {
      // udpEndpoint.port(port);
      socketUdp.open(boost::asio::ip::udp::v4());
      socketUdp.set_option(boost::asio::ip::udp::socket::reuse_address(true));
      boost::asio::ip::udp::endpoint endpoint(
          boost::asio::ip::address_v4::any(), port);
      // boost::asio::ip::udp::endpoint
      // endpoint(boost::asio::ip::address_v4::from_string("192.168.2.0/24"),
      // 7687);

      socketUdp.bind(endpoint);

      isUdpOpened = true;
      return true;

    } catch (std::exception &e) {
      std::cout << "openUdp:exception " << e.what() << std::endl;
      XTLOGWRN("exception");
    }
    return false;
  }

  void CommnunicationNet::closeUdp() {
    const std::lock_guard<std::mutex> lock(opencloseLock);

    if (isUdpOpened == false) return;
    isUdpOpened = false;

    XTLOGWRN("");

    boost::system::error_code error;
    try {
      socketUdp.cancel(error);
      socketUdp.close(error);
      std::cout << std::endl << "udp closed " << std::endl;
    } catch (std::exception &e) {
      std::cout << "closeUdp:exception " << e.what() << std::endl;
      XTLOGWRN("exception");
    }
    if (error) {
      std::cout << "udp already closed " << std::endl;
      XTLOGWRN("udp already closed ");
    }
  }

  bool CommnunicationNet::transmitCmd(uint8_t cmdId, XByteArray data) {
    if (isConnected == false) return false;

    uint32_t data_len = (uint32_t)(data.size());
    size_t payload_size = 1 + data_len + 2;

    std::ostringstream os;
    // start mark
    os << static_cast<uint8_t>(0x7E);
    os << static_cast<uint8_t>(0xFF);
    os << static_cast<uint8_t>(0xAA);
    os << static_cast<uint8_t>(0x55);

    // payload size
    os << static_cast<uint8_t>((payload_size >> 24) & 0xff);
    os << static_cast<uint8_t>((payload_size >> 16) & 0xff);
    os << static_cast<uint8_t>((payload_size >> 8) & 0xff);
    os << static_cast<uint8_t>((payload_size >> 0) & 0xff);

    os << static_cast<uint8_t>(cmdId);  // cmdid
    // data
    for (uint32_t i = 0; i < data_len; ++i) {
      os << static_cast<uint8_t>(data[i]);
    }

    os << static_cast<uint8_t>(0x00);  // statecode
    os << static_cast<uint8_t>(0x01);  // protocal version
    // end mark
    os << static_cast<uint8_t>(0xFF);
    os << static_cast<uint8_t>(0x7E);
    os << static_cast<uint8_t>(0x55);
    os << static_cast<uint8_t>(0xAA);

    boost::system::error_code error;

    socketTcp.write_some(boost::asio::buffer(os.str(), os.tellp()), error);
    if (error) {
      std::cout << "cmd wirte error" << std::endl;
      XTLOGWRN("cmd wirte error");
      return false;
    }
    return true;
  }

  CmdResp CommnunicationNet::receiveCmdPackage() {
    CmdResp resp;
    resp.cmdid = 0xff;
    if (isConnected == false) return resp;

    XByteArray buf(1500);
    boost::system::error_code error;

    uint32_t startmark = 0;
    uint32_t endmark = 0;
    uint32_t payloadlen = 0;

    size_t len = 0;
    try {
      len = socketTcp.read_some(boost::asio::buffer(buf), error);
      if (error) {
        std::cout << "tcp rx error" << std::endl;
        disconnect();
        return resp;
      }

    } catch (std::exception &e) {
      std::string logstr = "exception:read_some:exception ";
      logstr.append(e.what());
      std::cout << logstr << std::endl;
      XTLOGERR(logstr);
    }

    if (len < 15) return resp;

    buf.resize(len);
    startmark = Utils::getValueUint32BigEndian(&(buf[0]));
    endmark = Utils::getValueUint32BigEndian(&(buf[len - 4]));
    // if((buf_head[0] == 0x7E) && (buf_head[1] == 0xFF)&& (buf_head[2] ==
    // 0xAA)&& (buf_head[3] == 0x55))
    if ((startmark == 0x7EFFAA55) && (endmark == 0xFF7E55AA)) {
      // payloadlen = (int)buf_head[7]| (int)buf_head[6]<<8|
      // (int)buf_head[5]<<16| (int)buf_head[4]<<24;
      payloadlen = Utils::getValueUint32BigEndian(&(buf[4]));
      if (payloadlen != (buf.size() - 12)) return resp;

      resp.data.assign(buf.begin() + 9, buf.end() - 6);

      resp.cmdid = buf[8];
      resp.statecode = buf[len - 6];
      resp.ptclVer = buf[len - 5];
    }

    return resp;
  }

  UdpFrame CommnunicationNet::udpReceiveFrame() {
    UdpFrame udpframe;
    udpframe.statecode = 0xff;
    // udpframe.frame == nullptr;
    if (isUdpOpened == false) {
      return udpframe;
    }

    udp::endpoint remote_ep;
    boost::system::error_code ec;
    while (isUdpOpened) {
      size_t len = socketUdp.receive_from(boost::asio::buffer(udpRecvBuffer),
                                          remote_ep, 0, ec);

      if (ec && ec != boost::asio::error::message_size) {
        std::cout << "udp error" << len << std::endl;
        XTLOGWRN("udp error");

        return udpframe;
      }
      if (udppacket(udpRecvBuffer, udpframe.statecode)) {
        udpframe.frame = currentFrame;
        return udpframe;
      }
    }
  }

  bool CommnunicationNet::udppacket(const XByteArray &p, uint8_t &statecode) {
    uint16_t imagesn = (p[0] << 8) + p[1];
    uint32_t totalsize = (p[2] << 24) + (p[3] << 16) + (p[4] << 8) + p[5];
    uint16_t payloadSize = (p[6] << 8) + p[7];
    uint32_t sentsize
        = (p[8] << 24) + (p[9] << 16) + (p[10] << 8) + p[11];  // offset
    // uint32_t packetNum  = (p[16] << 24) + (p[17] << 16) + (p[18] << 8) +
    // p[19];

    uint32_t bufIndex = 10;
    // 找在用的index
    for (uint32_t i = 0; i < 3; i++) {
      if (data_isUsed[i] == 1)
        if (data_sn[i] == imagesn) bufIndex = i;
    }

    if (bufIndex > 2)
      // 找沒用的index
      for (uint32_t i = 0; i < 3; i++) {
        if (data_isUsed[i] == 0) {
          bufIndex = i;
          data_sn[bufIndex] = imagesn;
          data_size[bufIndex] = totalsize;
          data_count[bufIndex] = 0;
          data_isUsed[i] = 1;
        }
      }

    if (bufIndex > 2) {
      // 丟最早的index
      if (data_sn[0] < data_sn[1]) {
        bufIndex = 0;
        if (data_sn[0] > data_sn[2]) bufIndex = 2;
      } else if (data_sn[1] < data_sn[2])
        bufIndex = 1;
      else
        bufIndex = 2;

      if (data_sn[bufIndex] < 5)  // sn 翻转点处理
      {
        int validindex = 10;
        for (uint32_t i = 0; i < 3; i++) {
          if (bufIndex != i) {
            if (data_sn[i] > 65500) {
              validindex = i;
              break;
            }
          }
        }
        if (validindex < 3) {
          // XTLOGWRN("udp sn mirror0="+std::to_string(data_sn[validindex]));
          for (uint32_t i = 0; i < 3; i++) {
            if ((bufIndex != i) && (validindex != i)) {
              if (data_sn[i] > 65500) {
                if (data_sn[i] < data_sn[validindex])
                  bufIndex = i;
                else
                  bufIndex = validindex;
              } else
                bufIndex = validindex;
              XTLOGWRN("udp sn overturn=" + std::to_string(data_sn[bufIndex])
                       + ": " + std::to_string(data_sn[0]) + " "
                       + std::to_string(data_sn[1]) + " "
                       + std::to_string(data_sn[2]));
            }
          }
        }
      }
      std::cout << "udp discard frame " << std::to_string(data_sn[bufIndex])
                << std::endl;

      XTLOGWRN("udp discard frame " + std::to_string(data_sn[bufIndex]));
      data_isUsed[bufIndex] = 1;
      data_sn[bufIndex] = imagesn;
      data_size[bufIndex] = totalsize;
      data_count[bufIndex] = 0;
    }

    memcpy(&data_buffer[bufIndex][sentsize], &p[UDP_HEADER_OFFSET],
           payloadSize);
    data_count[bufIndex] += payloadSize;

    if (data_count[bufIndex] >= data_size[bufIndex]) {
      data_isUsed[bufIndex] = 0;

      uint16_t width
          = (data_buffer[bufIndex][8 + 4] << 8) + data_buffer[bufIndex][8 + 5];
      uint16_t height
          = (data_buffer[bufIndex][8 + 6] << 8) + data_buffer[bufIndex][8 + 7];
      int pixelDataOffset = 8;  //+8;

      int dataType = (int)data_buffer[bufIndex][8 + 1];
      uint16_t Frame_id = (int)data_buffer[bufIndex][8 + 3]
                          | (int)data_buffer[bufIndex][8 + 2] << 8;
      // currentFrame = std::shared_ptr<Frame>(new Frame(logtagname,dataType,
      // Frame_id, width, height, pixelDataOffset));
      currentFrame = std::make_shared<Frame>(logtagname, dataType, Frame_id,
                                             width, height, pixelDataOffset);
      uint32_t payloadlen = sentsize + payloadSize;

      uint32_t frame_temptpos
          = currentFrame->width * currentFrame->height * 2 + 8 + 8;

      if (currentFrame->dataType == Frame::AMPLITUDE)
        frame_temptpos
            = currentFrame->width * currentFrame->height * 2 * 2 + 8 + 8;
      if (payloadlen < (frame_temptpos + 40)) return false;

      statecode = data_buffer[bufIndex][payloadlen - 6];
      currentFrame->frame_version = data_buffer[bufIndex][payloadlen - 5];
      currentFrame->temperature = data_buffer[bufIndex][frame_temptpos + 1]
                                  | data_buffer[bufIndex][frame_temptpos] << 8;

      if (currentFrame->frame_version == 2) {
        currentFrame->roi_x0
            = (uint16_t)data_buffer[bufIndex][frame_temptpos + 3]
              | (uint16_t)data_buffer[bufIndex][frame_temptpos + 2] << 8;
        currentFrame->roi_y0
            = (uint16_t)data_buffer[bufIndex][frame_temptpos + 5]
              | (uint16_t)data_buffer[bufIndex][frame_temptpos + 4] << 8;

        if (currentFrame->roi_x0 > 310) currentFrame->roi_x0 = 0;

        if (currentFrame->roi_y0 > 110) currentFrame->roi_y0 = 0;

        currentFrame->binning = data_buffer[bufIndex][frame_temptpos + 6];
        currentFrame->vcseltemperature
            = data_buffer[bufIndex][frame_temptpos + 10]
              | data_buffer[bufIndex][frame_temptpos + 9] << 8;

        currentFrame->timeStampS = Utils::getValueUint48BigEndian(
            &(data_buffer[bufIndex][payloadlen - 4 - 14]));
        currentFrame->timeStampNS = Utils::getValueUint32BigEndian(
            &(data_buffer[bufIndex][payloadlen - 4 - 8]));
        currentFrame->timeStampState
            = data_buffer[bufIndex][payloadlen - 4 - 4];
        currentFrame->timeStampType = data_buffer[bufIndex][payloadlen - 4 - 3];

      } else {
        currentFrame->temperature
            = (data_buffer[bufIndex][sentsize + payloadSize - 56] << 8)
              + data_buffer[bufIndex][sentsize + payloadSize - 55];
        currentFrame->vcseltemperature = 0;
        currentFrame->timeStampState = 0;
        currentFrame->timeStampType = 0;

        if (currentFrame->frame_version > 2) {
          statecode = 0xff;
          return false;
        }
      }

      currentFrame->frameData.assign(
          data_buffer[bufIndex].begin() + 8,
          data_buffer[bufIndex].begin() + payloadlen);
      currentFrame->sortData(
          currentFrame->frameData);  // data_buffer[bufIndex]);  //copy data ->
                                     // dist, ampl
      currentFrame->timealg[1] = Utils::getTimeStamp();
      return true;
    }

    return false;
  }

}  // end namespace XinTan
