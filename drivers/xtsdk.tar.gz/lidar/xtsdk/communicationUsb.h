﻿/**************************************************************************************
* Copyright (C) 2022 Xintan Technology Corporation
*
* Author: Marco
***************************************************************************************/
#pragma once

#include "communication.h"

#include <boost/asio.hpp>
#include <boost/signals2.hpp>

using boost::asio::serial_port;

namespace XinTan {

class CommnunicationUsb: public Commnunication{

public:
    CommnunicationUsb(boost::asio::io_service& ios, std::string & logtag);
    ~CommnunicationUsb();
    std::string & logtagname;

    bool connect();
    void disconnect();
    bool openUdp(uint16_t port =7687);
    void closeUdp();
    bool transmitCmd(uint8_t cmdId, XByteArray data);

    CmdResp  receiveCmdPackage();
    UdpFrame udpReceiveFrame();

    serial_port  serialPort;

private:
    XByteArray RecvData;
    XByteArray usbRecvPacket;

    std::shared_ptr<Frame> currentFrame;

    XByteArray data;

};

} //end namespace xintan


