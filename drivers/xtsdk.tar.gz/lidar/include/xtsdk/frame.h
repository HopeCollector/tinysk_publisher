﻿/**************************************************************************************
 * Copyright (C) 2022 Xintan Technology Corporation
 *
 * Author: Marco
 ***************************************************************************************/
#pragma once

#include <cstdint>
#include <memory>
#include <vector>

#include "xtsdk/Iframe.h"
#include "xtsdk/xtlogger.h"

namespace XinTan {

  class Frame : public IFrame {
  public:
    Frame(std::string &logtag_, uint16_t dataType_, uint64_t frame_id_,
          uint16_t width_, uint16_t height_, uint16_t payloadOffset);
    enum DataType { AMPLITUDE, DISTANCE, RESERVER, GRAYSCALE };
    uint8_t frame_version;
    uint16_t pixelDataOffset;

    uint64_t frame_id;
    uint16_t dataType;  // frame数据类型
    uint16_t width;
    uint16_t height;
    uint32_t px_size;
    uint16_t roi_x0;
    uint16_t roi_y0;
    uint8_t binning;

    uint64_t timeStampS;     // 时间秒
    uint32_t timeStampNS;    // 纳秒
    uint8_t timeStampState;  // 时间同步状态
    uint8_t timeStampType;   // 时间同步类型

    int16_t temperature;       // 温度
    int16_t vcseltemperature;  // 灯板温度

    int dust_percent;  // 0~100为有效，负数为无效

    bool needxiacaiyang;  // 下采样用
    uint16_t xbinning;    // 下采样用
    uint16_t ybinning;    // 下采样用
    uint16_t orgwidth;    // 下采样用
    uint16_t orgheight;   // 下采样用

    bool hasPointcloud;  // 是否有点云数据

    std::vector<uint8_t> frameData;  // 原始数据

    std::vector<uint16_t> distData;  // 排序后的距离数据
    std::vector<uint16_t> amplData;  // 排序后的信号强度数据
    std::vector<uint16_t>
        reflectivity;                 // 反射率数据，通过距离和信号强度计算出的
    std::vector<XtPointXYZI> points;  // 点云数据，无序点云

    std::vector<uint16_t> rawdistData;  // 排序后的距离数据
    time_t timealg[8];                  // 保留测试用
    std::string &logtagname;

    void sortData(const XByteArray &);

    const int getDistDataSize();
    const uint16_t getDistData(const size_t &index);

    const time_t *getTimeAlg();
    // 纯虚函数声明
    uint8_t getFrameVersion();
    uint16_t getPixelDataOffset();
    uint64_t getFrameId();
    uint16_t getDataType();
    uint16_t getWidth();
    uint16_t getHeight();
    uint32_t getPxSize();
    uint16_t getRoiX0();
    uint16_t getRoiY0();
    uint8_t getBinning();
    uint64_t getTimeStampS();
    uint32_t getTimeStampNS();
    uint8_t getTimeStampState();
    uint8_t getTimeStampType();
    int16_t getTemperature();
    int16_t getVcselTemperature();
    uint32_t getDustPercent();
    bool getNeedXiaCaiYang();
    uint16_t getXBinning();
    uint16_t getYBinning();
    uint16_t getOrgWidth();
    uint16_t getOrgHeight();
    bool getHasPointCloud();

    // 设置属性的方法可以根据需要添加，这里只添加几个示例
    void setFrameId(uint64_t id);
    void setTimeStampS(uint64_t ts);
    void setDistdataIndex(const size_t &index, const uint16_t &data);

    void setDustPercent(uint32_t data);
  };

}  // end namespace XinTan
