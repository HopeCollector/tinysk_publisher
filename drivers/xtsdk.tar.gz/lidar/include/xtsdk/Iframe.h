#pragma execution_character_set("utf-8")
#pragma once

#include <vector>
#include <cstdint>
#include <ctime>    // for time_t

namespace XinTan {

    typedef std::vector<uint8_t> XByteArray;

    struct XtPointXYZI
    {
        float x;
        float y;
        float z;
        float intensity;
    };

    struct CamParameterS
    {
        float fx;
        float fy;
        float cx;
        float cy;
        float k1;
        float k2;
        float k3;
        float p1;
        float p2;
    };

    class IFrame {
    public:
        virtual ~IFrame() = default;

        // 纯虚函数声明
        virtual const int  getDistDataSize() = 0;
        virtual const uint16_t getDistData(const size_t& index) = 0;


        virtual uint8_t getFrameVersion()= 0;
        virtual uint16_t getPixelDataOffset()= 0;
        virtual uint64_t getFrameId()= 0;
        virtual uint16_t getDataType()= 0;
        virtual uint16_t getWidth()= 0;
        virtual uint16_t getHeight()= 0;
        virtual uint32_t getPxSize()= 0;
        virtual uint16_t getRoiX0()= 0;
        virtual uint16_t getRoiY0()= 0;
        virtual uint8_t getBinning()= 0;
        virtual uint64_t getTimeStampS()= 0;
        virtual uint32_t getTimeStampNS()= 0;
        virtual uint8_t getTimeStampState()= 0;
        virtual uint8_t getTimeStampType()= 0;
        virtual int16_t getTemperature()= 0;
        virtual int16_t getVcselTemperature()= 0;
        virtual uint32_t getDustPercent()= 0;
        virtual bool getNeedXiaCaiYang()= 0;
        virtual uint16_t getXBinning()= 0;
        virtual uint16_t getYBinning()= 0;
        virtual uint16_t getOrgWidth()= 0;
        virtual uint16_t getOrgHeight()= 0;
        virtual bool getHasPointCloud()= 0;


        virtual void setFrameId(uint64_t id) = 0;
        virtual void setTimeStampS(uint64_t ts) = 0;
        virtual void setDistdataIndex(const size_t& index, const uint16_t& data) = 0;
        virtual void setDustPercent(uint32_t data) =  0;

        virtual void sortData(const XByteArray& xByteArray) = 0;

    };

} // namespace XinTan
