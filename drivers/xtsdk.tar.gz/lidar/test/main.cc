﻿
#include <para_example.h>
#include <xtsdk/utils.h>
#include <xtsdk/xtsdk.h>

#include <atomic>
#include <boost/property_tree/ini_parser.hpp>
#include <boost/property_tree/ptree.hpp>
#include <chrono>
#include <csignal>
#include <iostream>
#include <string>
#include <thread>

using namespace XinTan;

XtSdk *xtsdk;
std::atomic<bool> keepRunning(true);
para_example para_set;
void eventCallback(const std::shared_ptr<CBEventData> &event) {
  std::cout << "event: " + event->eventstr + " " + std::to_string(event->cmdid)
            << std::endl;

  if (event->eventstr == "sdkState") {
    if (xtsdk->isconnect()
        && (event->cmdid == 0xfe))  // 端口打开后第一次连接上设备
    {
      xtsdk->stop();
      RespDevInfo devinfo;
      xtsdk->getDevInfo(devinfo);
      std::cout << std::endl << devinfo.fwVersion.c_str() << std::endl;
      std::cout << devinfo.sn.c_str() << devinfo.chipidStr << std::endl;

      XTAPPLOG("DEV SN=" + devinfo.sn);

      xtsdk->setModFreq(
          (ModulationFreq)para_set.lidar_setting_.frequency_modulation);
      xtsdk->setHdrMode((HDRMode)para_set.lidar_setting_.HDR);
      xtsdk->setIntTimesus(
          para_set.lidar_setting_.intgs, para_set.lidar_setting_.int1,
          para_set.lidar_setting_.int2, para_set.lidar_setting_.int3);
      xtsdk->setMinAmplitude(para_set.lidar_setting_.minLSB);
      xtsdk->setMaxFps(para_set.lidar_setting_.maxfps);
      xtsdk->setCutCorner(para_set.lidar_setting_.cut_corner);
      xtsdk->start((ImageType)para_set.lidar_setting_.imgType);
    }
    std::cout << "sdkstate= " + xtsdk->getStateStr() << std::endl;
  } else if (event->eventstr == "devState") {
    std::cout << "devstate= " + xtsdk->getStateStr() << std::endl;
  } else {
    if (event->cmdid == XinTan::REPORT_LOG)  // log
    {
      std::string logdata;
      logdata.assign(event->data.begin(), event->data.end());
      std::cout << "log: " << logdata << std::endl;
    }
    std::cout << "event: " + event->eventstr + " cmd="
              << std::to_string(event->cmdid) << std::endl;
  }
}

void imgCallback(const std::shared_ptr<Frame> &imgframe) {
  std::cout << "img: " + std::to_string((int)(imgframe->frame_id))
            << "size: " + std::to_string((int)(imgframe->points.size()))
            << std::endl;

  // imgframe->points: 点云数据 ,
  // imgframe->distData : 深度数据， uint16_t类型，尺寸
  // imgframe->height*imgframe->width imgframe->amplData :
  // 信号幅度数据或者灰度数据， uint16_t类型, 尺寸
  // imgframe->height*imgframe->width imgframe->distData : 深度数据，
  // uint16_t类型，尺寸 imgframe->height*imgframe->width
}

bool readIniFile(const std::string &filename, para_example &para_) {
  try {
    boost::property_tree::ptree pt;
    boost::property_tree::ini_parser::read_ini(filename, pt);

    // settings

    para_.lidar_setting_.frequency_modulation
        = pt.get<int>("Setting.frequency_modulation", 1);
    para_.lidar_setting_.HDR = pt.get<int>("Setting.HDR", 1);
    para_.lidar_setting_.imgType = pt.get<int>("Setting.imgType", 4);
    para_.lidar_setting_.cloud_coord = pt.get<int>("Setting.cloud_coord", 0);

    para_.lidar_setting_.int1 = pt.get<int>("Setting.int1", 100);
    para_.lidar_setting_.int2 = pt.get<int>("Setting.int2", 1000);
    para_.lidar_setting_.int3 = pt.get<int>("Setting.int3", 0);
    para_.lidar_setting_.intgs = pt.get<int>("Setting.intgs", 2000);
    para_.lidar_setting_.minLSB = pt.get<int>("Setting.minLSB", 80);
    para_.lidar_setting_.cut_corner = pt.get<int>("Setting.curcorner", 60);

    para_.lidar_setting_.start_stream
        = pt.get<bool>("Setting.start_stream", true);
    para_.lidar_setting_.connect_address
        = pt.get<std::string>("Setting.connect_address", "192.168.0.101");

    para_.lidar_setting_.maxfps = pt.get<int>("Setting.maxfps", 30);

    para_.lidar_setting_.hmirror = pt.get<bool>("Setting.hmirror", false);
    para_.lidar_setting_.vmirror = pt.get<bool>("Setting.vmirror", false);

    // filters
    para_.lidar_filter_.medianSize = pt.get<int>("Filters.medianSize", 5);
    para_.lidar_filter_.kalmanEnable = pt.get<int>("Filters.kalmanEnable", 1);
    para_.lidar_filter_.kalmanFactor
        = pt.get<float>("Filters.kalmanFactor", 0.4);
    para_.lidar_filter_.kalmanThreshold
        = pt.get<int>("Filters.kalmanThreshold", 400);
    para_.lidar_filter_.edgeEnable = pt.get<bool>("Filters.edgeEnable", true);
    para_.lidar_filter_.edgeThreshold
        = pt.get<int>("Filters.edgeThreshold", 200);
    para_.lidar_filter_.dustEnable = pt.get<bool>("Filters.dustEnable", true);
    para_.lidar_filter_.dustThreshold
        = pt.get<int>("Filters.dustThreshold", 2000);
    para_.lidar_filter_.dustFrames = pt.get<int>("Filters.dustFrames", 6);

    return true;
  } catch (const std::exception &e) {
    std::cout << "Error reading ini file" << std::endl;

    para_.lidar_setting_.frequency_modulation = 1;
    para_.lidar_setting_.HDR = 1;
    para_.lidar_setting_.imgType = 4;
    para_.lidar_setting_.cloud_coord = 0;

    para_.lidar_setting_.int1 = 100;
    para_.lidar_setting_.int2 = 1000;
    para_.lidar_setting_.int3 = 0;
    para_.lidar_setting_.intgs = 2000;
    para_.lidar_setting_.minLSB = 80;
    para_.lidar_setting_.cut_corner = 60;

    para_.lidar_setting_.start_stream = true;
    para_.lidar_setting_.connect_address = "192.168.0.101";

    para_.lidar_setting_.maxfps = 30;

    para_.lidar_setting_.hmirror = false;
    para_.lidar_setting_.vmirror = false;

    // filters
    para_.lidar_filter_.medianSize = 5;
    para_.lidar_filter_.kalmanEnable = 1;
    para_.lidar_filter_.kalmanFactor = 0.4;
    para_.lidar_filter_.kalmanThreshold = 400;
    para_.lidar_filter_.edgeEnable = true;
    para_.lidar_filter_.edgeThreshold = 200;
    para_.lidar_filter_.dustEnable = true;
    para_.lidar_filter_.dustThreshold = 2000;
    para_.lidar_filter_.dustFrames = 2;

    return false;
  }
}
void signalHandler(int signum) {
  std::cout << "Received signal " << signum << ", exiting ..." << std::endl;
  keepRunning = false;
}
int main(int argc, char *argv[]) {
  std::string cfg_path = std::string(EXAMPLE_DIR) + "/xintan.xtcfg";
  std::cout << "cfg_path: " << cfg_path << std::endl;
  if (readIniFile(cfg_path, para_set)) {
    std::cout << "Read ini file success!" << std::endl;
  } else {
    std::cout << "Read ini file failed!" << std::endl;
    // return -1;
  }

  xtsdk = new XtSdk();

  std::string addresstring = "";
  if (argc <= 1) {
    std::cout << "Invalid param!" << std::endl;
    return 0;
  }
  addresstring = argv[1];

  if (Utils::ipIsValid(addresstring) || Utils::isComport(addresstring)) {
    xtsdk->setConnectIpaddress(addresstring);
  } else {
    std::cout << "Invalid address or serialport!" << std::endl;
    return 0;
  }

  // xtsdk->setConnectIpaddress("192.168.2.101");
  // xtsdk->setConnectSerialportName("COM12"); //windows
  // xtsdk->setConnectSerialportName("/dev/ttyACM0"); //linux

  xtsdk->setSdkCloudCoordType(
      (ClOUDCOORD_TYPE)para_set.lidar_setting_.cloud_coord);
  xtsdk->setCallback(eventCallback, imgCallback);

  if (para_set.lidar_filter_.edgeEnable) {
    xtsdk->setSdkEdgeFilter(para_set.lidar_filter_.edgeThreshold);
    // xtsdk->setSdkEdgeFilter(200);
  }
  if (para_set.lidar_filter_.kalmanEnable) {
    xtsdk->setSdkKalmanFilter(para_set.lidar_filter_.kalmanFactor * 1000,
                              para_set.lidar_filter_.kalmanThreshold,
                              2000);  // sdk中开启卡尔曼滤波
    // xtsdk->setSdkKalmanFilter(300, 300, 2000);
  }
  if (para_set.lidar_filter_.medianSize > 0) {
    xtsdk->setSdkMedianFilter(
        para_set.lidar_filter_.medianSize);  // sdk中执行3*3的中值滤波
                                             // xtsdk->setSdkMedianFilter(3);
  }
  if (para_set.lidar_filter_.dustEnable) {
    xtsdk->setSdkDustFilter(para_set.lidar_filter_.dustThreshold,
                            para_set.lidar_filter_.dustFrames);
    // xtsdk->setSdkDustFilter(2002, 6);
  }

  xtsdk->startup();

  std::signal(SIGINT, signalHandler);
  std::thread worker([]() {
    while (keepRunning) {
      std::this_thread::sleep_for(std::chrono::seconds(1));
    }
  });
  worker.join();

  xtsdk->stop();
  xtsdk->setCallback();
  xtsdk->shutdown();
  return 0;
}
