#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#include <Camera/cam.hh>
#include <fstream>
#include <iostream>
#include <vector>

// clang-format off
// const char* pipeline
//     = "v4l2src device=/dev/video0 !"
//       "video/x-raw width=640 height=480 framerate=30/1 !"
//       "videoconvert !"
//       "v4l2jpegenc extra-controls=\"encode,video_bitrate_mode=1,video_bitrate=2500000\" !"
//       "videorate ! image/jpeg framerate=10/1 !"
//       "jpegparse ! appsink name=s";

const char* pipeline
    = "v4l2src device=/dev/video2 !"
      "video/x-raw, width=640, height=480, framerate=30/1 !"
      "videoconvert ! jpegenc !"
      "videorate ! image/jpeg framerate=10/1 !"
      "jpegparse ! appsink name=s";
// clang-format on

void send_image_data(int sockfd, const sockaddr_in& server_addr, uint8_t* data,
                     size_t sz) {
  size_t total_size = sz;
  size_t sent_size = 0;
  int cnt = 0;
  while (sent_size < total_size) {
    ssize_t bytes_sent = sendto(
        sockfd, data + sent_size, total_size - sent_size, 0,
        reinterpret_cast<const sockaddr*>(&server_addr), sizeof(server_addr));
    if (bytes_sent < 0) {
      std::cerr << "Failed to send data" << std::endl;
      break;
    }
    sent_size += bytes_sent;
    cnt++;
  }
  std::cout << "Sent " << sent_size << " bytes in " << cnt << " packets"
            << std::endl;
}

int main() {
  camera::Camera camera{pipeline};
  if (!camera.connect()) {
    return -1;
  }

  int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd < 0) {
    std::cerr << "Failed to create socket" << std::endl;
    return -1;
  }

  sockaddr_in server_addr{};
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(8291);
  if (inet_pton(AF_INET, "172.21.0.1", &server_addr.sin_addr) <= 0) {
    std::cerr << "Invalid address/ Address not supported" << std::endl;
    close(sockfd);
    return -1;
  }

  std::string name = "video";
  size_t max_sz = 640 * 480 * 3;
  uint8_t buffer[max_sz + name.size()];
  std::copy(name.begin(), name.end(), buffer);
  while (true) {
    auto read_sz = camera.capture(buffer + name.size(), max_sz);
    if (read_sz == 0) {
      std::cerr << "Failed to capture image" << std::endl;
      continue;
    }
    send_image_data(sockfd, server_addr, buffer, read_sz + name.size());
  }

  return 0;
}